@echo off
setlocal
title Hynhi Phicom - Cai dat
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Kiem-tra-va-cai.ps1" %*
if errorlevel 1 pause
