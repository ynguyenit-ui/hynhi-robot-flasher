param([string]$Ip = "")

$ErrorActionPreference = 'Stop'
try {
    $checks = @{
        'Ung-dung\Hynhi-Phicom.apk' = '6C8C08714F10024DD3BA013E5F405DA34387D33BBFBF8AD1C0D0CB0A3F510A5C'
        'Ung-dung\install.ps1' = 'F095F9A2D02914A261F1D9AAC233C61E2A8ADB783672D299CF5E0933890EFA5C'
        'Cap-nhat-OTA.ps1' = 'A7EBAE3CE0F0CBA2021A584182711A96324462D6177D759CEA3098D90FE78CAE'
    }
    foreach ($file in $checks.Keys) {
        $location = Join-Path $PSScriptRoot $file
        if ((Get-FileHash -LiteralPath $location).Hash -ne $checks[$file]) {
            throw "Tep $file khong khop bo cai Hynhi. Hay giai nen lai."
        }
    }
    & (Join-Path $PSScriptRoot 'Ung-dung\install.ps1') -Ip $Ip
} catch {
    Write-Host "[LOI] $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
