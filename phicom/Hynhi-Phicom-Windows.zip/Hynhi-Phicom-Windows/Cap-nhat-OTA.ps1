param(
    [string]$Ip,
    [string]$Apk = (Join-Path $PSScriptRoot 'Ung-dung\Hynhi-Phicom.apk'),
    [string]$AdbPath,
    [int]$AdbPort = 5038,
    [switch]$Reboot
)

$ErrorActionPreference = 'Stop'
function Read-Speaker([string]$Address) {
    try {
        $request = [Net.HttpWebRequest]::Create("http://${Address}:8088/api/state")
        $request.Proxy = $null
        $request.Timeout = 1800
        $reply = $request.GetResponse()
        try {
            $reader = [IO.StreamReader]::new($reply.GetResponseStream())
            try { return $reader.ReadToEnd() | ConvertFrom-Json } finally { $reader.Dispose() }
        } finally { $reply.Dispose() }
    } catch { return $null }
}

try {
    if (-not $Ip) {
        $saved = Join-Path $env:LOCALAPPDATA 'HynhiPhicom\speaker.json'
        if (-not (Test-Path -LiteralPath $saved)) { $saved = Join-Path $env:LOCALAPPDATA 'HynhiPhicom\media-v1\speaker.json' }
        if (Test-Path -LiteralPath $saved) {
            $setup = Get-Content -LiteralPath $saved -Raw | ConvertFrom-Json
            $candidate = Read-Speaker $setup.speakerIp
            if ($candidate -and $candidate.device_id -eq $setup.deviceId) { $Ip = $setup.speakerIp }
        }
    }
    if (-not $Ip) { $Ip = (Read-Host 'Nhap IP hien tai cua loa (muc Wi-Fi)').Trim() }
    $parsed = [Net.IPAddress]::None
    if ($Ip -notmatch '^\d{1,3}(\.\d{1,3}){3}$' -or
        -not [Net.IPAddress]::TryParse($Ip, [ref]$parsed)) { throw 'IP IPv4 khong hop le.' }
    $speaker = Read-Speaker $Ip
    if ($speaker -and (-not $speaker.device_id -or -not $speaker.app_version)) { throw "Khong phai trang dieu khien Hynhi." }
    $Apk = (Resolve-Path -LiteralPath $Apk).Path
    if (-not $AdbPath) {
        $AdbPath = Join-Path $PSScriptRoot 'Ung-dung\platform-tools\adb.exe'
        if (-not (Test-Path -LiteralPath $AdbPath)) {
            $installedAdb = Get-Command adb.exe -ErrorAction SilentlyContinue
            if ($installedAdb) { $AdbPath = $installedAdb.Source }
            else {
                $tools = Join-Path $env:LOCALAPPDATA 'HynhiPhicom\android-tools'
                [void](New-Item -ItemType Directory -Force $tools)
                $AdbPath = Join-Path $tools 'platform-tools\adb.exe'
                if (-not (Test-Path -LiteralPath $AdbPath)) {
                    $download = Join-Path $tools 'platform-tools.zip'
                    Invoke-WebRequest -UseBasicParsing 'https://dl.google.com/android/repository/platform-tools-latest-windows.zip' -OutFile $download
                    Expand-Archive -LiteralPath $download -DestinationPath $tools -Force
                }
            }
        }
    }
    function Invoke-HynhiAdb([string[]]$Command, [int]$Timeout = 12) {
        $process = [Diagnostics.Process]::new()
        $process.StartInfo.FileName = $AdbPath
        $argsForClient = @('-P', [string]$AdbPort) + $Command
        $process.StartInfo.Arguments = ($argsForClient | ForEach-Object { '"' + $_.Replace('"','\"') + '"' }) -join ' '
        $process.StartInfo.UseShellExecute = $false
        $process.StartInfo.CreateNoWindow = $true
        $process.StartInfo.RedirectStandardOutput = $true
        $process.StartInfo.RedirectStandardError = $true
        try {
            [void]$process.Start()
            $log = $process.StandardOutput.ReadToEndAsync()
            $errorLog = $process.StandardError.ReadToEndAsync()
            if (-not $process.WaitForExit($Timeout * 1000)) {
                $process.Kill()
                return @{Code=-1; Output='het thoi gian cho'}
            }
            $output = ''
            if ($log.Wait(2000)) { $output += $log.Result }
            if ($errorLog.Wait(2000)) { $output += $errorLog.Result }
            return @{Code=$process.ExitCode; Output=$output}
        } finally { $process.Dispose() }
    }
    function Reconnect-Hynhi {
        [void](Invoke-HynhiAdb @('disconnect',$serial) 5)
        $link = Invoke-HynhiAdb @('connect',$serial) 12
        return ($link.Code -eq 0 -and $link.Output -match 'connected to')
    }
    $serial = "${Ip}:5555"
    & $AdbPath -P $AdbPort start-server
    if ($LASTEXITCODE) { throw 'Khong chay duoc ADB.' }
    try {
        if (-not (Reconnect-Hynhi)) { throw 'Khong ket noi duoc ADB Wi-Fi.' }
        for ($try = 0; $try -lt 5; $try++) {
            $identified = Invoke-HynhiAdb @('-s',$serial,'shell','dumpsys package vn.dbrobot.r1') 10
            if ($identified.Output -match 'versionName=[^\r\n]*-hynhi') { break }
            Start-Sleep -Milliseconds 500
        }
        if ($identified.Output -notmatch 'versionName=[^\r\n]*-hynhi') { throw 'Dia chi nay khong hien co ung dung Hynhi.' }
        Write-Host "Dang chuyen ban cap nhat toi loa $Ip..."
        $remoteApk = '/data/local/tmp/hynhi-ota.apk'
        $staged = Invoke-HynhiAdb @('-s',$serial,'push',$Apk,$remoteApk) 340
        if ($staged.Code -ne 0) { throw "Chua chuyen tron tep APK: $($staged.Output.Trim())" }
        if (-not (Reconnect-Hynhi)) { throw 'Tep da chuyen. Chua ket noi lai duoc de cai.' }
        $command = 'rm -f /data/local/tmp/hynhi-ota-result.txt; (trap "" HUP; pm install -r /data/local/tmp/hynhi-ota.apk > /data/local/tmp/hynhi-ota-result.txt 2>&1; echo exit=$? >> /data/local/tmp/hynhi-ota-result.txt) </dev/null >/dev/null 2>&1 &'
        [void](Invoke-HynhiAdb @('-s',$serial,'shell',$command) 7)
        $deadline = (Get-Date).AddSeconds(180)
        $installLog = ''
        do {
            Start-Sleep -Seconds 3
            $check = Invoke-HynhiAdb @('-s',$serial,'shell','cat /data/local/tmp/hynhi-ota-result.txt') 7
            if ($check.Code -ne 0) { [void](Reconnect-Hynhi); continue }
            $installLog = $check.Output
            if ($installLog -match 'exit=') { break }
        } while ((Get-Date) -lt $deadline)
        if ($installLog -notmatch 'exit=0' -or $installLog -notmatch 'Success') { throw "Loa chua xac nhan cap nhat: $installLog" }
        [void](Reconnect-Hynhi)
        if ($Reboot) {
            [void](Invoke-HynhiAdb @('-s',$serial,'reboot') 12)
            Write-Host 'Dang doi loa khoi dong lai...'
            Start-Sleep -Seconds 8
        } else {
            [void](Invoke-HynhiAdb @('-s',$serial,'shell','am force-stop vn.dbrobot.r1; am start -n vn.dbrobot.r1/info.dourok.voicebot.MainActivity') 12)
        }
    } finally {
        [void](Invoke-HynhiAdb @('disconnect',$serial) 5)
    }
    $attempts = if ($Reboot) { 40 } else { 24 }
    for ($attempt = 0; $attempt -lt $attempts; $attempt++) {
        $current = Read-Speaker $Ip
        if ($current -and (-not $speaker -or $current.device_id -eq $speaker.device_id)) {
            try {
                $setupRoot = Join-Path $env:LOCALAPPDATA 'HynhiPhicom'
                [void](New-Item -ItemType Directory -Force $setupRoot)
                @{speakerIp=$Ip; deviceId=$current.device_id} | ConvertTo-Json |
                    Set-Content -LiteralPath (Join-Path $setupRoot 'speaker.json') -Encoding UTF8
            } catch { }
            Write-Host "Hynhi $($current.app_version) dang chay tai http://${Ip}:8088/"
            exit 0
        }
        Start-Sleep -Milliseconds 750
    }
    throw 'APK da cai. Hay khoi dong lai loa va mo trang dieu khien bang IP hien tai cua loa.'
} catch {
    Write-Host "[LOI] $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
