@echo off
chcp 65001 >nul
cd /d "%~dp0"
set /p LOAIP=IP cua loa Hynhi Phicom (Enter de tu tim):
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0CaiDat-DesktopBridge.ps1" -LoaIp "%LOAIP%"
pause
