﻿# Bộ cài Hynhi Phicom cho loa Phicomm R1 — cài qua Wi-Fi của loa hoặc qua mạng nhà.
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Adb = Join-Path $Root "adb\adb.exe"
$Apk = Join-Path $Root "HynhiPhicom.apk"
$Pkg = "vn.hynhi.phicom"
$StockPkgs = @("com.phicomm.speaker.device", "com.phicomm.speaker.otaservice",
               "com.phicomm.speaker.exceptionreporter", "com.phicomm.speaker.bugreport")

# ------------------------------------------------------------------ màu Hynhi
$cBg    = [System.Drawing.Color]::FromArgb(5, 13, 31)
$cCard  = [System.Drawing.Color]::FromArgb(10, 28, 62)
$cCyan  = [System.Drawing.Color]::FromArgb(34, 211, 238)
$cGold  = [System.Drawing.Color]::FromArgb(246, 196, 69)
$cText  = [System.Drawing.Color]::FromArgb(230, 243, 255)
$cMuted = [System.Drawing.Color]::FromArgb(143, 179, 217)
$fBase  = New-Object System.Drawing.Font("Segoe UI", 10)
$fBold  = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)

$form = New-Object System.Windows.Forms.Form
$form.Text = "Hynhi Phicom — Bộ cài cho loa Phicomm R1"
$form.Size = New-Object System.Drawing.Size(640, 720)
$form.StartPosition = "CenterScreen"
$form.BackColor = $cBg
$form.ForeColor = $cText
$form.Font = $fBase
$form.FormBorderStyle = "FixedSingle"
$form.MaximizeBox = $false
$iconPath = Join-Path $Root "logo.jpg"

# ------------------------------------------------------------------ đầu trang
$logo = New-Object System.Windows.Forms.PictureBox
$logo.Location = New-Object System.Drawing.Point(20, 16)
$logo.Size = New-Object System.Drawing.Size(96, 96)
$logo.SizeMode = "Zoom"
if (Test-Path $iconPath) { $logo.Image = [System.Drawing.Image]::FromFile($iconPath) }
$form.Controls.Add($logo)

$title = New-Object System.Windows.Forms.Label
$title.Text = "Hynhi Phicom"
$title.Font = New-Object System.Drawing.Font("Segoe UI", 26, [System.Drawing.FontStyle]::Bold)
$title.ForeColor = $cGold
$title.Location = New-Object System.Drawing.Point(128, 20)
$title.AutoSize = $true
$form.Controls.Add($title)

$sub = New-Object System.Windows.Forms.Label
$sub.Text = "TRÍ TUỆ NHÂN TẠO · Cài đặt cho loa Phicomm R1"
$sub.ForeColor = $cCyan
$sub.Font = $fBold
$sub.Location = New-Object System.Drawing.Point(132, 70)
$sub.AutoSize = $true
$form.Controls.Add($sub)

function New-Label($text, $x, $y, $w = 580, $color = $cMuted) {
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $text; $l.ForeColor = $color
    $l.Location = New-Object System.Drawing.Point($x, $y)
    $l.Size = New-Object System.Drawing.Size($w, 22)
    $form.Controls.Add($l); return $l
}
function New-Box($x, $y, $w, $text = "", $pass = $false) {
    $t = New-Object System.Windows.Forms.TextBox
    $t.Location = New-Object System.Drawing.Point($x, $y)
    $t.Size = New-Object System.Drawing.Size($w, 26)
    $t.BackColor = $cCard; $t.ForeColor = $cText; $t.BorderStyle = "FixedSingle"
    $t.Text = $text
    if ($pass) { $t.UseSystemPasswordChar = $true }
    $form.Controls.Add($t); return $t
}
function New-Button($text, $x, $y, $w, $primary = $false) {
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $text
    $b.Location = New-Object System.Drawing.Point($x, $y)
    $b.Size = New-Object System.Drawing.Size($w, 38)
    $b.FlatStyle = "Flat"
    $b.Font = $fBold
    if ($primary) { $b.BackColor = $cCyan; $b.ForeColor = $cBg; $b.FlatAppearance.BorderSize = 0 }
    else { $b.BackColor = $cCard; $b.ForeColor = $cText; $b.FlatAppearance.BorderColor = $cCyan }
    $form.Controls.Add($b); return $b
}

# ------------------------------------------------------------------ bước 1: kết nối
New-Label "1. Kết nối tới loa" 20 128 580 $cGold | Out-Null
$rbAp = New-Object System.Windows.Forms.RadioButton
$rbAp.Text = "Qua Wi-Fi của loa (máy tính đang nối Wi-Fi Phicomm_R1_xxxx)"
$rbAp.Location = New-Object System.Drawing.Point(28, 152); $rbAp.Size = New-Object System.Drawing.Size(580, 24)
$rbAp.Checked = $true
$form.Controls.Add($rbAp)
$rbLan = New-Object System.Windows.Forms.RadioButton
$rbLan.Text = "Qua mạng nhà (loa và máy tính cùng Wi-Fi) — IP loa:"
$rbLan.Location = New-Object System.Drawing.Point(28, 178); $rbLan.Size = New-Object System.Drawing.Size(360, 24)
$form.Controls.Add($rbLan)
$tbIp = New-Box 392 178 200 "192.168.43.1"
$lblWifi = New-Label "" 28 206 580

# ------------------------------------------------------------------ bước 2: Wi-Fi nhà
New-Label "2. Wi-Fi nhà cho loa (để loa vào Internet sau khi cài)" 20 240 580 $cGold | Out-Null
New-Label "Tên Wi-Fi:" 28 268 90 | Out-Null
$tbSsid = New-Box 120 266 230
New-Label "Mật khẩu:" 362 268 80 | Out-Null
$tbPass = New-Box 440 266 152 "" $true
$cbWifi = New-Object System.Windows.Forms.CheckBox
$cbWifi.Text = "Kết nối loa vào Wi-Fi này sau khi cài xong"
$cbWifi.Location = New-Object System.Drawing.Point(28, 298); $cbWifi.Size = New-Object System.Drawing.Size(560, 24)
$cbWifi.Checked = $true
$form.Controls.Add($cbWifi)
$cbPc = New-Object System.Windows.Forms.CheckBox
$cbPc.Text = "Cài điều khiển máy tính này bằng giọng nói (Desktop Bridge, tự ghép với loa)"
$cbPc.Location = New-Object System.Drawing.Point(28, 320); $cbPc.Size = New-Object System.Drawing.Size(560, 24)
$cbPc.Checked = $true
$form.Controls.Add($cbPc)

# ------------------------------------------------------------------ bước 3: cài
New-Label "3. Cài đặt" 20 352 580 $cGold | Out-Null
$btnInstall = New-Button "⚡ CÀI ĐẶT HYNHI PHICOM" 28 378 300 $true
$btnOpen = New-Button "🌐 Mở trang điều khiển" 340 378 252
$btnRestore = New-Button "↩ Khôi phục loa gốc" 340 422 252

$prog = New-Object System.Windows.Forms.ProgressBar
$prog.Location = New-Object System.Drawing.Point(28, 428); $prog.Size = New-Object System.Drawing.Size(300, 26)
$prog.Maximum = 7
$form.Controls.Add($prog)

$log = New-Object System.Windows.Forms.TextBox
$log.Multiline = $true; $log.ScrollBars = "Vertical"; $log.ReadOnly = $true
$log.Location = New-Object System.Drawing.Point(28, 466); $log.Size = New-Object System.Drawing.Size(564, 200)
$log.BackColor = [System.Drawing.Color]::FromArgb(2, 8, 20); $log.ForeColor = $cCyan
$log.Font = New-Object System.Drawing.Font("Consolas", 9)
$form.Controls.Add($log)

function Log($m) {
    $log.AppendText((Get-Date -Format "HH:mm:ss") + "  " + $m + "`r`n")
    [System.Windows.Forms.Application]::DoEvents()
}
function Step($n) { $prog.Value = [Math]::Min($n, $prog.Maximum); [System.Windows.Forms.Application]::DoEvents() }

function Run-Adb([string[]]$adbArgs, [int]$timeoutSec = 120) {
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $Adb
    $psi.Arguments = ($adbArgs | ForEach-Object { if ($_ -match '\s') { '"' + $_ + '"' } else { $_ } }) -join ' '
    $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true
    $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true
    $p = [System.Diagnostics.Process]::Start($psi)
    $outTask = $p.StandardOutput.ReadToEndAsync(); $errTask = $p.StandardError.ReadToEndAsync()
    $sw = [Diagnostics.Stopwatch]::StartNew()
    while (-not $p.HasExited) {
        [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 100
        if ($sw.Elapsed.TotalSeconds -gt $timeoutSec) { try { $p.Kill() } catch {}; return "TIMEOUT" }
    }
    return ($outTask.Result + $errTask.Result).Trim()
}

function Get-Target {
    if ($rbAp.Checked) { return "192.168.43.1" } else { return $tbIp.Text.Trim() }
}

function Show-CurrentWifi {
    $ssid = (netsh wlan show interfaces) | Select-String '^\s+SSID\s+:\s+(.+)$' | ForEach-Object { $_.Matches[0].Groups[1].Value.Trim() } | Select-Object -First 1
    if ($ssid) {
        $lblWifi.Text = "Máy tính đang nối Wi-Fi: $ssid"
        if ($ssid -like "Phicomm_R1*") { $rbAp.Checked = $true; $lblWifi.ForeColor = $cCyan }
        else { $lblWifi.ForeColor = $cMuted; if (-not $tbSsid.Text) { $tbSsid.Text = $ssid } }
    } else { $lblWifi.Text = "Không đọc được Wi-Fi hiện tại" }
}

function Connect-Speaker($ip) {
    Log "Kết nối adb tới $ip`:5555 ..."
    Run-Adb @("disconnect") 10 | Out-Null
    for ($i = 1; $i -le 5; $i++) {
        $r = Run-Adb @("connect", "$ip`:5555") 20
        Log "  $r"
        $state = Run-Adb @("-s", "$ip`:5555", "get-state") 10
        if ($state -eq "device") { return $true }
        Start-Sleep -Seconds 2
    }
    return $false
}

function Wait-Web($ip, $sec) {
    for ($i = 0; $i -lt $sec; $i++) {
        try { $r = Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 "http://$ip`:8088/api/status"; if ($r.StatusCode -eq 200) { return $true } } catch {}
        [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Seconds 1
    }
    return $false
}

$btnInstall.Add_Click({
    $btnInstall.Enabled = $false
    try {
        $log.Clear(); Step 0
        if (-not (Test-Path $Adb)) { Log "LỖI: thiếu adb\adb.exe"; return }
        if (-not (Test-Path $Apk)) { Log "LỖI: thiếu HynhiPhicom.apk"; return }
        $ip = Get-Target
        $s = "$ip`:5555"
        if (-not (Connect-Speaker $ip)) { Log "LỖI: không kết nối được loa. Kiểm tra Wi-Fi / IP và thử lại."; return }
        Step 1
        $model = Run-Adb @("-s", $s, "shell", "getprop ro.product.model; getprop ro.build.version.release") 15
        Log "Loa: $($model -replace "`r?`n", ' / Android ')"
        Step 2

        Step 3

        Log "Đang cài HynhiPhicom.apk (1-3 phút qua Wi-Fi)..."
        $r = Run-Adb @("-s", $s, "push", $Apk, "/data/local/tmp/hynhi.apk") 400; Log "  $r"
        $r = Run-Adb @("-s", $s, "shell", "/system/bin/pm install -r /data/local/tmp/hynhi.apk") 400; Log "  $r"
        Run-Adb @("-s", $s, "shell", "rm /data/local/tmp/hynhi.apk") 20 | Out-Null
        if ($r -notmatch "Success") { Log "LỖI: cài không thành công."; return }
        Step 4

        Log "Khởi động Hynhi Phicom..."
        Run-Adb @("-s", $s, "shell", "am start -n $Pkg/.MainActivity") 20 | Out-Null
        Step 5
        if (Wait-Web $ip 40) { Log "✔ Trang điều khiển đã chạy: http://$ip`:8088" } else { Log "Chưa thấy trang 8088 (sẽ thử tiếp sau)." }
        Step 6

        $wifiSent = $false
        if ($cbWifi.Checked -and $tbSsid.Text.Trim()) {
            $ssid = $tbSsid.Text.Trim()
            Log "Gửi Wi-Fi nhà '$ssid' cho loa..."
            try {
                $body = @{ ssid = $ssid; password = $tbPass.Text } | ConvertTo-Json -Compress
                $bytes = [System.Text.Encoding]::UTF8.GetBytes($body)
                $body = @{ ssid = $ssid; password = $tbPass.Text; secure = $(if ($tbPass.Text) { "WPA" } else { "INSECURE" }) } | ConvertTo-Json -Compress
                $bytes = [System.Text.Encoding]::UTF8.GetBytes($body)
                # Dịch vụ cài mạng gốc của Phicomm (netctl, cổng 8989) — cách app Phicomm vẫn dùng
                Invoke-WebRequest -UseBasicParsing -TimeoutSec 8 -Method Post -ContentType "application/json; charset=utf-8" -Body $bytes "http://$ip`:8989/api/configwifi" | Out-Null
                $wifiSent = $true
                Log "✔ Đã gửi Wi-Fi nhà (loa sẽ chuyển mạng sau ~6 giây)."
            } catch { Log "Không gửi được Wi-Fi: $($_.Exception.Message)" }
        }
        # Tắt app gốc SAU CÙNG: app gốc quản lý Wi-Fi cài đặt, tắt nó là mất kết nối tới loa.
        Log "Tắt ứng dụng giọng nói gốc (giải phóng micro)..."
        foreach ($p in $StockPkgs) {
            $r = Run-Adb @("-s", $s, "shell", "/system/bin/pm hide $p") 15
            Log "  $p -> $r"
        }
        if ($wifiSent) {
            Log "Máy tính sẽ mất Wi-Fi loa — hãy nối lại Wi-Fi nhà, tìm IP mới của loa trên router, mở http://<IP>:8088"
        } else {
            Log "Chưa gửi Wi-Fi nhà: loa có thể không còn phát Wi-Fi cài đặt. Nếu vậy rút điện cắm lại loa."
        }
        if ($cbPc.Checked) {
            $bridge = Join-Path $Root "desktop-bridge\CaiDat-DesktopBridge.ps1"
            if (Test-Path $bridge) {
                Log "Cài Desktop Bridge cho máy tính này (tự tìm và ghép với loa khi cùng Wi-Fi nhà)..."
                Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$bridge`"" -WindowStyle Normal
            } else { Log "Không thấy thư mục desktop-bridge — bỏ qua." }
        }
        Step 7
        Log "HOÀN TẤT! Lần đầu: tab Đánh thức > Tải mô hình tiếng Việt; tab Máy chủ AI > nhập mã kích hoạt trên xiaozhi.me."
    } finally { $btnInstall.Enabled = $true }
})

$btnOpen.Add_Click({ Start-Process ("http://" + (Get-Target) + ":8088") })

$btnRestore.Add_Click({
    if ([System.Windows.Forms.MessageBox]::Show("Gỡ Hynhi Phicom và bật lại ứng dụng gốc của Phicomm?", "Khôi phục", "YesNo") -ne "Yes") { return }
    $ip = Get-Target; $s = "$ip`:5555"
    if (-not (Connect-Speaker $ip)) { Log "Không kết nối được loa"; return }
    foreach ($p in $StockPkgs) {
        Run-Adb @("-s", $s, "shell", "/system/bin/pm unhide $p") 20 | Out-Null
        Run-Adb @("-s", $s, "shell", "/system/bin/pm enable $p") 20 | Out-Null
        Log "  bật lại $p"
    }
    Log (Run-Adb @("-s", $s, "uninstall", $Pkg) 60)
    Log "Đã khôi phục. Rút điện loa rồi cắm lại."
})

$form.Add_Shown({
    Show-CurrentWifi
    Log "Sẵn sàng. Nối máy tính vào Wi-Fi Phicomm_R1_xxxx của loa (hoặc chọn mạng nhà), nhập Wi-Fi nhà rồi bấm CÀI ĐẶT."
})
[void]$form.ShowDialog()
Run-Adb @("disconnect") 5 | Out-Null
