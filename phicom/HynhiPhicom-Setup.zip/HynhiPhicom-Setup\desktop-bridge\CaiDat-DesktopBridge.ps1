﻿# Cài Hynhi Desktop Bridge cho loa Hynhi Phicom (máy tính Windows cùng Wi-Fi với loa).
# Bridge chủ động lấy lệnh từ loa (cổng 8080 của loa) - không mở cổng vào máy tính.
param([string]$LoaIp = "")
$ErrorActionPreference = "Stop"
$src = Split-Path -Parent $MyInvocation.MyCommand.Path
$dst = Join-Path $env:LOCALAPPDATA "HynhiPhicomDesktop"
Write-Host "== Hynhi Phicom Desktop Bridge ==" -ForegroundColor Cyan

New-Item -ItemType Directory -Force $dst | Out-Null
Get-ChildItem $src -Exclude ".local", ".venv", "CaiDat-DesktopBridge.*" | Copy-Item -Destination $dst -Recurse -Force
Write-Host "Đã chép bridge vào $dst"

# Python: dùng lại môi trường của bridge Hynhi Robot nếu có, nếu không thì tạo mới
$robotVenv = Join-Path $env:LOCALAPPDATA "HynhiDesktop\.venv\Scripts\pythonw.exe"
$ownVenv = Join-Path $dst ".venv\Scripts\pythonw.exe"
if (Test-Path $robotVenv) {
    $pyw = $robotVenv
    Write-Host "Dùng lại Python của Hynhi Desktop (robot)"
} elseif (Test-Path $ownVenv) {
    $pyw = $ownVenv
} else {
    $py = (Get-Command python -ErrorAction SilentlyContinue).Source
    if (-not $py) { Write-Host "Chưa có Python 3. Cài tại https://www.python.org/downloads/ (tích Add to PATH) rồi chạy lại." -ForegroundColor Red; Read-Host "Enter để thoát"; exit 1 }
    Write-Host "Đang tạo môi trường Python và cài thư viện (vài phút)..."
    & $py -m venv (Join-Path $dst ".venv")
    & (Join-Path $dst ".venv\Scripts\python.exe") -m pip install -q -r (Join-Path $dst "requirements.txt")
    $pyw = $ownVenv
}

$argList = @("`"$dst\start_hidden.pyw`"", "--browser-profile", "default", "--allow-folder", "`"$env:USERPROFILE`"", "--port", "8775")
if ($LoaIp) { $argList += @("--robot-url", "http://${LoaIp}:8080") }
$argLine = $argList -join " "

# Tự chạy khi đăng nhập Windows
$startup = [Environment]::GetFolderPath("Startup")
$lnk = Join-Path $startup "HynhiPhicomDesktop.lnk"
$ws = New-Object -ComObject WScript.Shell
$sc = $ws.CreateShortcut($lnk)
$sc.TargetPath = $pyw
$sc.Arguments = $argLine
$sc.WorkingDirectory = $dst
$sc.Description = "Hynhi Phicom Desktop Bridge"
$sc.Save()
Write-Host "Đã thêm tự khởi động: $lnk"

# Dừng bản cũ của bridge loa (nếu có) rồi chạy
Get-CimInstance Win32_Process -Filter "name='pythonw.exe'" | Where-Object { $_.CommandLine -like "*HynhiPhicomDesktop*" } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
Start-Process -FilePath $pyw -ArgumentList $argLine -WorkingDirectory $dst -WindowStyle Hidden
Write-Host "Bridge đang chạy. Mở trang điều khiển loa > tab Máy tính để xem trạng thái." -ForegroundColor Green
Write-Host "Nhật ký: $dst\.local\startup.log"
