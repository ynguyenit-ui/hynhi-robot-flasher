"""Local desktop companion with authenticated commands and default Chrome profile."""
import argparse
import hmac
import json
import os
from pathlib import Path
import secrets
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlsplit, quote
from urllib.request import Request
import time


def web_url(value):
    value = str(value)
    parsed = urlsplit(value)
    if parsed.scheme not in ('http', 'https') or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError('Chỉ chấp nhận địa chỉ web http/https')
    if len(value) > 2048:
        raise ValueError('Địa chỉ quá dài')
    return value


class Desktop:
    def __init__(self, profile, roots, headless=False):
        self.profile, self.roots, self.headless = profile, roots, headless
        self.driver = self.context = None

    def browser(self):
        if self.context is not None:
            browser = self.context.browser
            if browser is not None and not browser.is_connected():
                self.context = None
                self.selected = None
        if self.context is None:
            from playwright.sync_api import sync_playwright
            if self.driver is None:
                self.driver = sync_playwright().start()
            self.context = self.driver.chromium.launch_persistent_context(
                str(self.profile), channel='chrome', headless=self.headless,
                accept_downloads=False, viewport=None)
            created_context = self.context
            self.context.on('close', lambda *_: self.browser_closed(created_context))
            self.context.set_default_timeout(10000)
            self.context.on('page', lambda page: page.on('dialog', lambda dialog: dialog.dismiss()))
        return self.context

    def browser_closed(self, closed_context):
        if self.context is closed_context:
            self.context = None
            self.selected = None

    def page(self):
        context = self.browser()
        selected = getattr(self, 'selected', None)
        return selected if selected is not None and not selected.is_closed() else (context.pages[-1] if context.pages else context.new_page())

    def execute(self, command):
        from playwright.sync_api import Error
        try:
            return self._execute(command)
        except Error as error:
            if 'has been closed' not in str(error):
                raise
            self.selected = None
            if self.context is not None:
                browser = self.context.browser
                if browser is None or not browser.is_connected():
                    self.context = None
            # A close event can arrive only when the next command pumps Playwright.
            return self._execute(command)

    def _execute(self, command):
        action, value = command.get('action'), command.get('value', '')
        search_notice = None
        if action == 'open_folder':
            target = Path(value).expanduser().resolve(strict=True)
            if not target.is_dir() or not any(target == root or root in target.parents for root in self.roots):
                raise ValueError('Thư mục nằm ngoài danh sách cho phép')
            os.startfile(str(target))
            return {'ok': True, 'folder': str(target)}
        if action in ('open_url', 'new_tab', 'search'):
            url = 'https://www.google.com/search?q=' + quote(str(value)[:500]) if action == 'search' else web_url(value)
            page = self.browser().new_page() if action == 'new_tab' else self.page()
            page.goto(url, wait_until='domcontentloaded', timeout=15000)
            if action == 'search' and 'google.com/sorry' in page.url:
                page.goto('https://www.bing.com/search?q=' + quote(str(value)[:500]), wait_until='domcontentloaded', timeout=15000)
                search_notice = 'Google yêu cầu xác minh; đã tìm bằng Bing'
            page.bring_to_front()
            self.selected = page
        elif action == 'scroll':
            direction = -1 if value == 'up' else 1
            self.page().mouse.wheel(0, direction * 650)
        elif action == 'select_tab':
            index = int(value)
            pages = self.browser().pages
            if not 0 <= index < len(pages):
                raise ValueError('Tab không tồn tại')
            pages[index].bring_to_front()
            # Move selected tab to last position in our explicit selection.
            self.selected = pages[index]
        elif action not in ('scan_page', 'read_page', 'status'):
            raise ValueError('Lệnh không được hỗ trợ')
        page = getattr(self, 'selected', None)
        if page is None or page.is_closed() or action in ('open_url','new_tab','search'):
            page = self.page()
        result = {'ok': True, 'title': page.title(), 'url': page.url,
                  'tabs': [{'index': i, 'title': p.title(), 'url': p.url} for i, p in enumerate(self.browser().pages)][:20]}
        if search_notice:
            result['notice'] = search_notice
            result['title'] = search_notice + ' · ' + result['title']
        if action in ('scan_page', 'read_page'):
            # Fixed DOM inspection only: website text never becomes executable commands.
            offset = max(0, int(value or 0)) if action == 'read_page' else 0
            data = page.evaluate('''offset => ({text:(document.body?.innerText||'').slice(offset,offset+8000),total:(document.body?.innerText||'').length,links:Array.from(document.querySelectorAll('main a[href],article a[href],h2 a[href],h3 a[href]')).map(a=>({title:(a.innerText||a.getAttribute('aria-label')||'').trim(),url:a.href})).filter(a=>a.title.length>12&&/^https?:/.test(a.url)).slice(0,80)})''', offset)
            unique = {}
            for link in data['links']:
                unique.setdefault(link['url'], link)
            terms = str(value).lower().split()
            result.update(content_is_untrusted=True, text=data['text'], total_characters=data['total'], next_offset=offset+8000 if offset+8000<data['total'] else None,
                          articles=sorted(unique.values(), key=lambda x: sum(t in x['title'].lower() for t in terms), reverse=True)[:12])
        return result

    def close(self):
        if self.context:
            context = self.context
            context.close()
            self.context = None
        if self.driver:
            self.driver.stop()


class DefaultProfileDesktop(Desktop):
    def __init__(self, profile, roots, token):
        super().__init__(profile, roots, False)
        from native_browser import NativeBrowser
        self._catalog = None
        self.browser_control = NativeBrowser()
        self.zalo = None
        self.ui = None

    @property
    def catalog(self):
        if self._catalog is None:
            from windows_apps import AppCatalog
            self._catalog=AppCatalog()
        return self._catalog

    def execute(self, command):
        from windows_apps import open_default_chrome, shortcuts
        import file_index
        action, value = command.get('action'), command.get('value', '')
        if not isinstance(action,str):raise ValueError('Thiếu tên lệnh máy tính')
        if action=='system_volume':
            from desktop_ui import system_volume
            return system_volume(value)
        if action in ('ui_read','ui_click','mouse','ui_type','ui_keys'):
            from desktop_ui import DesktopUI
            if self.ui is None:self.ui=DesktopUI()
            return self.ui.execute(action,value)
        if action.startswith('zalo_'):
            from zalo_control import ZaloControl
            if self.zalo is None:self.zalo=ZaloControl(self.catalog)
            if action=='zalo_find':return self.zalo.find(value)
            if action=='zalo_select':return self.zalo.select(value)
            values=json.loads(value) if isinstance(value,str) else value
            if not isinstance(values,dict):raise ValueError('Thông số Zalo cần dạng JSON')
            if action=='zalo_draft':return self.zalo.compose(values)
            if action=='zalo_send':return self.zalo.send(values)
            raise ValueError('Lệnh Zalo không hỗ trợ')
        if action == 'apps_list':
            return {'ok':True,'apps':self.catalog.find(value) if value else self.catalog.apps[:120],'total_apps':len(self.catalog.apps),'installed': [a for a in self.catalog.installed if not value or str(value).casefold() in a['name'].casefold()][:50]}
        if action == 'app_close':
            return self.catalog.close(value)
        if action == 'app_open':
            return self.catalog.open(value)
        if action == 'inventory_refresh':
            self.catalog.refresh()
            return {'ok':True,'apps':len(self.catalog.apps),'shortcuts':len(shortcuts()),'files':file_index.start()}
        if action == 'inventory_status':
            return {'ok':True,'apps':len(self.catalog.apps),'installed_apps':len(self.catalog.installed),'file_index':file_index.status(),'shortcuts':shortcuts()[:80],'taskbar':self.catalog.taskbar()}
        if action == 'file_search':
            return {'ok':True,'items':file_index.search(value)}
        if action in ('index_start','index_resume','index_pause'):
            return {'ok':True,'file_index':file_index.pause() if action=='index_pause' else file_index.start()}
        if action == 'file_open':
            target,is_dir=file_index.item(value)
            if not target.exists():raise ValueError('File không còn tồn tại ở vị trí đã nhớ; chạy quét lại')
            if not is_dir and target.suffix.lower() not in {'.pdf','.txt','.md','.docx','.xlsx','.pptx','.csv','.jpg','.jpeg','.png','.webp','.gif','.mp3','.wav','.mp4','.mkv','.html','.htm'}:raise ValueError('Loại file này cần mở thủ công; ứng dụng đã cài dùng app_open')
            os.startfile(str(target))
            return {'ok':True,'opened':str(target)}
        if action == 'open_folder':
            target=Path(value).expanduser().resolve(strict=True)
            if not target.is_dir() or str(target).startswith('\\\\') or target.drive.casefold() not in [Path(r).drive.casefold() for r in file_index.roots()]:raise ValueError('Chỉ mở thư mục trên các ổ cục bộ đã cho phép quét')
            os.startfile(str(target))
            return {'ok':True,'folder':str(target)}
        return self.browser_control.execute(command)

    def close(self):
        pass  # The user's default browser stays open.


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--bind', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=8767)
    parser.add_argument('--robot-ip')
    parser.add_argument('--allow-folder', action='append', default=[])
    parser.add_argument('--browser-profile',choices=['default','isolated'],default='default')
    parser.add_argument('--robot-url', help='Robot lấy lệnh qua kết nối đi từ PC, không cần mở firewall')
    parser.add_argument('--headless', action='store_true')
    args = parser.parse_args()
    connection_file=Path(__file__).parent/'.local'/'connection.json'
    if not args.robot_url and connection_file.exists():
        try:args.robot_url=json.loads(connection_file.read_text(encoding='utf-8')).get('robot_url')
        except (ValueError,OSError):pass
    if args.robot_url:
        connection_file.parent.mkdir(exist_ok=True)
        connection_file.write_text(json.dumps({'robot_url':args.robot_url}),encoding='utf-8')
    if args.bind != '127.0.0.1' and not args.robot_ip:
        parser.error('Khi mở mạng LAN cần --robot-ip để giới hạn máy gửi lệnh')
    state = Path(__file__).parent / '.local'
    state.mkdir(exist_ok=True)
    token_file = state / 'token'
    if not token_file.exists():
        token_file.write_text(secrets.token_urlsafe(32), encoding='utf-8')
    token = token_file.read_text(encoding='utf-8').strip()
    robot_mac_file = state / 'robot_mac'
    robot_mac = robot_mac_file.read_text(encoding='ascii').strip().lower() if robot_mac_file.exists() else ''
    robot_token_file = state / 'robot_token'
    robot_token = robot_token_file.read_text(encoding='utf-8').strip() if robot_token_file.exists() else token
    import socket,ctypes
    from robot_discovery import announce, discover, verify, lan_open, peer_mac
    from ctypes import wintypes
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.CreateMutexW.argtypes=[ctypes.c_void_p,wintypes.BOOL,wintypes.LPCWSTR]
    kernel.CreateMutexW.restype=wintypes.HANDLE
    ctypes.set_last_error(0)
    mutex=kernel.CreateMutexW(None,False,'Local\\HynhiDesktopBridge')
    if not mutex:raise OSError('Không tạo được khóa cầu nối Hynhi')
    if ctypes.get_last_error()==183:
        print('Một cầu nối Hynhi đã chạy.');return
    pc_name=socket.gethostname().encode('ascii','replace').decode()[:63]
    job_file=state/'last_job'
    desktop = (DefaultProfileDesktop(state / 'chrome-profile', [Path(p).resolve(strict=True) for p in args.allow_folder], token) if args.browser_profile=='default' else Desktop(state / 'chrome-profile', [Path(p).resolve(strict=True) for p in args.allow_folder], args.headless))

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass  # Never log URLs, page contents, or pairing credentials.

        def do_POST(self):
            if self.path != '/command' or self.client_address[0] not in ('127.0.0.1', args.robot_ip):
                self.send_error(403); return
            if not hmac.compare_digest(self.headers.get('Authorization', ''), 'Bearer ' + token):
                self.send_error(401); return
            size = int(self.headers.get('Content-Length', '0'))
            if not 1 <= size <= 16384:
                self.send_error(413); return
            try:
                command = json.loads(self.rfile.read(size))
                if not isinstance(command, dict):
                    raise ValueError('JSON không hợp lệ')
                result = desktop.execute(command)
            except Exception as error:
                result = {'ok': False, 'error': str(error)[:300]}
            body = json.dumps(result, ensure_ascii=False).encode()
            self.send_response(200)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers(); self.wfile.write(body)

    print('Desktop bridge ready. Pairing token: tools/desktop_bridge/.local/token (keep private).')
    try:
        server = HTTPServer((args.bind, args.port), Handler)
        server.timeout = 0.25
        last_job = job_file.read_text(encoding='utf-8').strip() if job_file.exists() else None
        last_result = {'ok':False,'error':'PC đã khởi động lại; hãy yêu cầu lại lệnh nếu cần.'}
        failures=0;next_discovery=0;next_verify=0;next_announce=0;verified=False
        while True:
            server.handle_request()
            if isinstance(desktop, DefaultProfileDesktop):
                desktop.browser_control.skip_youtube_ad()
            now=time.monotonic()
            if not verified and args.robot_url and now>=next_verify:
                verified=verify(args.robot_url,robot_token)
                next_verify=now+5  # every attempt is a new TCP connection on a small robot HTTP server
                if verified:failures=0
            if not verified and now>=next_discovery:
                offered={}
                found=discover(args.robot_url,robot_token,pc_name,offered.__setitem__,robot_mac)
                next_discovery=time.monotonic()+15
                if found:
                    if found in offered:
                        robot_token=offered[found]
                        temporary=robot_token_file.with_suffix('.tmp')
                        temporary.write_text(robot_token,encoding='utf-8')
                        temporary.replace(robot_token_file)
                    args.robot_url=found;failures=0;verified=True
                    if not robot_mac:
                        robot_mac=peer_mac(found)
                        if robot_mac:robot_mac_file.write_text(robot_mac,encoding='ascii')
                    connection_file.write_text(json.dumps({'robot_url':found}),encoding='utf-8')
            if not args.robot_url or not verified:continue
            try:
                request = Request(args.robot_url.rstrip('/') + '/api/desktop/pull', headers={'Authorization':'Bearer ' + robot_token,'X-Hynhi-PC':pc_name})
                with lan_open(request, timeout=2) as reply:
                    task = json.load(reply)
                failures=0
                if time.monotonic()>=next_announce:
                    announce(args.robot_url,pc_name,.8)
                    next_announce=time.monotonic()+30
                if not task.get('job'):
                    time.sleep(0.75)  # idle polling about once per second keeps the robot's web server responsive
                    continue
                if task['job'] != last_job:
                    job_file.write_text(str(task['job']),encoding='utf-8')
                    try:
                        last_result = desktop.execute(task['command'])
                    except Exception as error:
                        last_result = {'ok':False,'error':str(error)[:300]}
                    last_job = task['job']
                response = {'action':'_result','job':last_job,'result':last_result}
                body = json.dumps(response,ensure_ascii=False).encode()
                while len(body)>10000:
                    if last_result.get('text'):
                        last_result['text']=last_result['text'][:len(last_result['text'])//2]
                        last_result['next_offset']=int(task['command'].get('value') or 0)+len(last_result['text'].encode('utf-16-le'))//2 if task['command']['action']=='read_page' else len(last_result['text'].encode('utf-16-le'))//2
                    elif last_result.get('articles'):
                        last_result['articles'].pop()
                    elif last_result.get('tabs'):
                        last_result['tabs'].pop()
                    elif any(isinstance(last_result.get(k),list) and last_result[k] for k in ['apps','installed','shortcuts','taskbar','items','contacts','videos','controls','choose_app']):
                        key=max((k for k in ['apps','installed','shortcuts','taskbar','items','contacts','videos','controls','choose_app'] if isinstance(last_result.get(k),list) and last_result[k]),key=lambda k:len(json.dumps(last_result[k],ensure_ascii=False)))
                        last_result[key].pop()
                        last_result['truncated']=True
                    else:
                        raise ValueError('Kết quả quá lớn')
                    body=json.dumps(response,ensure_ascii=False).encode()
                request=Request(args.robot_url.rstrip('/')+'/api/desktop',data=body,headers={'Authorization':'Bearer '+robot_token,'Content-Type':'application/json'})
                with lan_open(request,timeout=3) as reply:
                    reply.read()
            except Exception:
                failures+=1
                if failures>=3:verified=False;next_discovery=0;next_announce=0
                time.sleep(0.5)
    finally:
        desktop.close()


if __name__ == '__main__':
    main()
