// Fixed news DOM reader. Returned page text is data, never executable instructions.
const newsPages=new Map();
function newsCollect(){
 const articlesOnPage=document.querySelectorAll('article');
 const root=(articlesOnPage.length===1&&articlesOnPage[0].querySelectorAll('p').length>=3?articlesOnPage[0]:null)||document.querySelector('main,[role="main"],#main-content,.main-content,.content-detail')||document.body;
 const text=(root?.innerText||'').replace(/\n{3,}/g,'\n\n').slice(0,180000);
 const candidates=Array.from(document.querySelectorAll('h1 a[href],h2 a[href],h3 a[href],h4 a[href],article a[href],main a[href],[role="main"] a[href],a[title]'));if(candidates.length<5)candidates.push(...document.querySelectorAll('a[href]'));
 const seen=new Set(),articles=[];
 for(const a of candidates){
  if(a.closest('nav,footer,header,[role="navigation"],.advertisement,.ads,.banner-ads'))continue;
  const title=(a.innerText||a.getAttribute('title')||a.getAttribute('aria-label')||'').replace(/\s+/g,' ').trim();if(title.length<12||title.length>240)continue;
  let url;try{url=new URL(a.href,location.href);if(!['http:','https:'].includes(url.protocol)||url.username||url.password||url.pathname===location.pathname&&url.search===location.search)continue;}catch{continue;}
  url.hash='';if(seen.has(url.href)||/\.(?:exe|msi|zip|rar|apk)(?:$|\?)/i.test(url.href))continue;seen.add(url.href);
  let hash=2166136261;for(const c of url.href)hash=Math.imul(hash^c.charCodeAt(0),16777619);articles.push({article_id:(hash>>>0).toString(16),title,url:url.href});if(articles.length>=60)break;
 }
 return {text,articles,document_title:document.title};
}
function newsFold(s){return String(s).toLocaleLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/\s+/g,' ').trim();}
async function newsCommand(command){
 let current=command.target_tab_id?await chrome.tabs.get(command.target_tab_id):await tab();if(!command.target_tab_id&&['news_scan','scan_page'].includes(command.action)){const active=await chrome.tabs.query({active:true,lastFocusedWindow:true});if(active[0])current=active[0];}if(!/^https?:\/\//.test(current.url||''))throw Error('Mở một trang báo/web trước');selectedTab=current.id;
 const collect=async()=>{const [{result:data}]=await chrome.scripting.executeScript({target:{tabId:current.id},func:newsCollect});return data;};
 let state=newsPages.get(current.id),value=command.value||'',action=command.action;
 if(action==='article_open'){
  if(!state||state.url!==current.url||Date.now()-state.created>1200000)throw Error('Danh sách bài đã thay đổi/hết hạn; quét trang báo lại trước');
  const key=String(value).trim();let matches=state.articles.filter(a=>a.article_id===key);
  if(!matches.length&&/^\d+$/.test(key)){const n=Number(key);if(n>=1&&n<=state.selection.length)matches=[state.selection[n-1]];}
  if(!matches.length){const q=newsFold(key);if(q)matches=state.articles.filter(a=>newsFold(a.title).includes(q)||q.split(' ').every(w=>newsFold(a.title).includes(w)));}
  if(matches.length!==1)return {ok:false,error:matches.length?'Có nhiều bài trùng chủ đề; chọn article_id hoặc số thứ tự cụ thể':'Chưa thấy bài đó trong danh sách vừa quét',articles:matches.slice(0,8),content_is_untrusted:true};
  current=await chrome.tabs.update(current.id,{url:webUrl(matches[0].url),active:true});await chrome.windows.update(current.windowId,{focused:true});await new Promise(r=>setTimeout(r,400));current=await ready(current.id);state=null;
 }
 if(!state||state.url!==current.url||action==='news_scan'||action==='scan_page'||action==='article_open'){
  let data=await collect();for(let attempt=0;attempt<3&&data.text.length<120;++attempt){await new Promise(r=>setTimeout(r,450));data=await collect();}state={...data,url:current.url,created:Date.now(),selection:data.articles};newsPages.set(current.id,state);if(newsPages.size>20)newsPages.delete(newsPages.keys().next().value);
 }
 if(action==='news_scan'||action==='scan_page'){
  const terms=newsFold(value).split(' ').filter(Boolean);const score=a=>terms.reduce((n,w)=>n+Number(newsFold(a.title).includes(w)),0);state.selection=[...state.articles].sort((a,b)=>score(b)-score(a)).slice(0,12);
 }
 const offset=action==='read_page'?Math.max(0,Number(value)||0):0;if(!Number.isInteger(offset))throw Error('Vị trí đọc không hợp lệ');
 return {ok:true,title:state.document_title||current.title,url:current.url,content_is_untrusted:true,text:state.text.slice(offset,offset+4000),offset,total_characters:state.text.length,next_offset:offset+4000<state.text.length?offset+4000:null,articles:(action==='article_open'?[]:state.selection).slice(0,12).map((a,i)=>({...a,index:i+1})),notice:state.text?'Nội dung đã tải trên trang; chọn article_id hoặc số bài để mở rồi đọc.':'Trang chưa có văn bản đọc được; có thể cần tải xong/đăng nhập/đồng ý trên PC',browser_profile:'default'};
}
