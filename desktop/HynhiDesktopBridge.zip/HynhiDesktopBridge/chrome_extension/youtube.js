// YouTube commands use fixed DOM operations, never scripts supplied by page content.
const youtubeWindows=new Map();
async function youtubeDom(operation,argument){
 const host=location.hostname;if(host!=='www.youtube.com'&&host!=='youtube.com')throw Error('Chọn tab YouTube trước');
 if(operation==='results'){
  const seen=new Set();return Array.from(document.querySelectorAll('ytd-video-renderer a#video-title')).flatMap(a=>{const u=new URL(a.href),id=u.searchParams.get('v');if(!/^[\w-]{11}$/.test(id||'')||seen.has(id)||a.closest('ytd-ad-slot-renderer,ytd-promoted-video-renderer'))return [];seen.add(id);return [{video_id:id,title:a.textContent.trim(),url:'https://www.youtube.com/watch?v='+id}];}).slice(0,12);
 }
 const video=document.querySelector('video');if(!video)throw Error('Video chưa sẵn sàng hoặc YouTube yêu cầu đăng nhập/đồng ý');
 const number=(value,min,max)=>{const n=Number(value);if(!Number.isFinite(n)||n<min||n>max)throw Error('Giá trị điều khiển không hợp lệ');return n;};
 if(operation==='focus'){document.getElementById('hynhi-video-fullscreen')?.remove();video.tabIndex=0;video.focus();}
 else if(operation==='play'){try{await video.play();}catch{throw Error('Chrome chặn tự phát; bấm Phát một lần trong YouTube rồi thử lại');}}
 else if(operation==='pause')video.pause();
 else if(operation==='seek'){if(!Number.isFinite(video.duration))throw Error('Video trực tiếp không hỗ trợ tua theo thời gian');video.currentTime=Math.max(0,Math.min(video.duration,video.currentTime+number(argument,-3600,3600)));}
 else if(operation==='volume')video.volume=number(argument,0,100)/100;
 else if(operation==='mute')video.muted=true;
 else if(operation==='unmute')video.muted=false;
 else if(operation==='rate')video.playbackRate=number(argument,.25,2);
 else if(operation==='next'){const b=document.querySelector('.ytp-next-button');if(!b||b.getAttribute('aria-disabled')==='true')throw Error('Không có video tiếp theo');b.click();}
 else if(operation==='captions'){const b=document.querySelector('.ytp-subtitles-button');if(!b||b.getAttribute('aria-disabled')==='true')throw Error('Video không có phụ đề');b.click();}
 else if(operation==='fullscreen'){
  if(!document.getElementById('hynhi-video-fullscreen')){const style=document.createElement('style');style.id='hynhi-video-fullscreen';style.textContent='#movie_player{position:fixed!important;inset:0!important;width:100vw!important;height:100vh!important;z-index:2147483647!important;background:#000!important}#movie_player .html5-video-container{width:100%!important;height:100%!important}#movie_player video{position:absolute!important;inset:0!important;width:100%!important;height:100%!important;object-fit:contain!important}';document.head.append(style);}
 }else if(operation==='exit_fullscreen')document.getElementById('hynhi-video-fullscreen')?.remove();
 else if(operation!=='status')throw Error('Lệnh video không hỗ trợ');
 return {native_fullscreen:!!document.fullscreenElement,paused:video.paused,muted:video.muted,volume:Math.round(video.volume*100),current_time:video.currentTime,duration:Number.isFinite(video.duration)?video.duration:null,rate:video.playbackRate,fullscreen_layout:!!document.getElementById('hynhi-video-fullscreen'),ad_playing:!!document.querySelector('.ad-showing')};
}
async function youtubeCommand(command){
 let current=await tab(),action=command.action,value=command.value||'';
 const onYoutube=t=>{try{return ['www.youtube.com','youtube.com'].includes(new URL(t.url).hostname);}catch{return false;}};
 if(!onYoutube(current)){const all=await chrome.tabs.query({});current=all.find(onYoutube)||await chrome.tabs.create({url:'https://www.youtube.com/',active:true});}
 current=await chrome.tabs.update(current.id,{active:true});selectedTab=current.id;{const w=await chrome.windows.get(current.windowId);if(w.state==='minimized')await chrome.windows.update(w.id,{state:'normal'});await chrome.windows.update(current.windowId,{focused:true});}await enableYoutubeSkip(current.id);
 const dom=async(op,arg)=>{const r=await chrome.scripting.executeScript({target:{tabId:current.id},func:youtubeDom,args:[op,arg??null]});return r[0].result;};
 const navigate=async url=>{current=await chrome.tabs.update(current.id,{url});await new Promise(r=>setTimeout(r,400));current=await ready(current.id);};
 let videos=[];
 if(action==='youtube_search'||action==='youtube_play'){
  let options={};if(typeof value==='string'&&value.trim().startsWith('{')){options=JSON.parse(value);if(!options||typeof options!=='object'||Array.isArray(options))throw Error('Thông số YouTube không hợp lệ');}else options={query:String(value)};
  let id=options.video_id;const query=String(options.query||'').trim();
  if(id&&!/^[\w-]{11}$/.test(id))throw Error('Mã video không hợp lệ');
  if(!id){if(!query||query.length>500)throw Error('Nhập tên video cần tìm');await navigate('https://www.youtube.com/results?search_query='+encodeURIComponent(query));for(let i=0;i<24;i++){videos=await dom('results');if(videos.length)break;await new Promise(r=>setTimeout(r,400));}if(!videos.length)throw Error('Chưa lấy được kết quả YouTube; kiểm tra mạng, màn hình đồng ý hoặc đăng nhập trên PC');if(action==='youtube_search')return {ok:true,videos,content_is_untrusted:true,title:'Kết quả YouTube',browser_profile:'default'};id=videos[0].video_id;}
  await navigate('https://www.youtube.com/watch?v='+id);
  await enableYoutubeSkip(current.id);
  let media;for(let i=0;i<20;i++){try{media=await dom('status');break;}catch{await new Promise(r=>setTimeout(r,400));}}if(!media)throw Error('Đã mở video nhưng trình phát chưa sẵn sàng');
  let notice='';try{media=await dom('play');}catch(e){notice=e.message;}
  if(options.fullscreen!==false){await dom('fullscreen');const w=await chrome.windows.get(current.windowId);if(!youtubeWindows.has(w.id))youtubeWindows.set(w.id,w.state);await chrome.windows.update(w.id,{state:'fullscreen'});}
  return {ok:true,title:current.title,url:'https://www.youtube.com/watch?v='+id,media,notice:notice||'Đã mở video; quảng cáo hoặc yêu cầu đăng nhập vẫn do YouTube xử lý',browser_profile:'default',fullscreen:options.fullscreen!==false};
 }
 const values=typeof value==='string'?JSON.parse(value||'{"operation":"status"}'):value;if(!values||typeof values!=='object')throw Error('Thông số video cần dạng JSON');
 const operation=String(values.operation||'status');if(operation==='focus'){const w=await chrome.windows.get(current.windowId);if(youtubeWindows.has(w.id)){await chrome.windows.update(w.id,{state:youtubeWindows.get(w.id)||'normal'});youtubeWindows.delete(w.id);}}const media=await dom(operation,values.amount);
 if(operation==='fullscreen'){const w=await chrome.windows.get(current.windowId);if(!youtubeWindows.has(w.id))youtubeWindows.set(w.id,w.state);await chrome.windows.update(w.id,{state:'fullscreen'});}
 if(operation==='exit_fullscreen'){await chrome.windows.update(current.windowId,{state:youtubeWindows.get(current.windowId)||'normal'});youtubeWindows.delete(current.windowId);}
 return {ok:true,title:current.title,url:current.url,media,browser_profile:'default'};
}
