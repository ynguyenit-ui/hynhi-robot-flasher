// Only clicks YouTube's own visible, enabled Skip Ad button on robot-controlled tabs.
(()=>{
 if(globalThis.__hynhiSkipInstalled)return;globalThis.__hynhiSkipInstalled=true;let enabled=false,last=0;
 chrome.runtime.sendMessage({type:'hynhi-youtube-skip-query'},reply=>{if(!chrome.runtime.lastError)enabled=reply?.enabled===true;});
 chrome.runtime.onMessage.addListener(message=>{if(message.type==='hynhi-youtube-skip-enable')enabled=message.enabled===true;});
 setInterval(()=>{
  if(!enabled||document.hidden||Date.now()-last<1800)return;
  const player=document.querySelector('#movie_player.ad-showing');if(!player)return;
  for(const element of player.querySelectorAll('.ytp-skip-ad-button,.ytp-ad-skip-button-modern,.ytp-ad-skip-button')){
   const b=element.closest('button')||element;const r=b.getBoundingClientRect(),style=getComputedStyle(b);if(b.disabled||b.getAttribute('aria-disabled')==='true'||r.width<2||r.height<2||style.display==='none'||style.visibility==='hidden')continue;
   b.click();last=Date.now();break;
  }
 },700);
})();
