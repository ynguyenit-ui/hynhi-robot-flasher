import asyncio,json,threading,time,uuid
class BrowserRelay:
 def __init__(self,token):self.token=token;self.loop=None;self.socket=None;self.pending={};self.lock=threading.Lock();self.error=None
 def start(self):
  def worker():
   try:asyncio.run(self.run())
   except Exception as error:self.error=str(error)
  threading.Thread(target=worker,name='hynhi-browser',daemon=True).start()
 async def run(self):
  from websockets.asyncio.server import serve
  self.loop=asyncio.get_running_loop()
  async def handler(ws):
   origin=ws.request.headers.get('Origin','')
   if not origin.startswith('chrome-extension://') or ws.remote_address[0]!='127.0.0.1':await ws.close(code=1008);return
   try:
    import hmac
    first=json.loads(await asyncio.wait_for(ws.recv(),timeout=5))
    if first.get('type')!='auth' or not hmac.compare_digest(str(first.get('token','')),self.token):await ws.close(code=1008);return
    if self.socket and self.socket is not ws:await self.socket.close(code=1000,reason='New paired browser')
    self.socket=ws
    async for raw in ws:
     message=json.loads(raw)
     if message.get('type')=='ping':await ws.send('{"type":"pong"}');continue
     with self.lock:pending=self.pending.get(str(message.get('id','')))
     if pending:pending['result']=message.get('result',{});pending['event'].set()
   finally:
    if self.socket is ws:self.socket=None
  async with serve(handler,'127.0.0.1',8766,max_size=131072,ping_interval=20):await asyncio.Future()
 def connected(self):return self.socket is not None
 def execute(self,command):
  if not self.socket or not self.loop:raise ValueError('Chrome mặc định chưa ghép tiện ích Hynhi. Cài tiện ích trong chrome_extension và nhập token trên PC.')
  task_id=uuid.uuid4().hex;pending={'event':threading.Event()}
  with self.lock:self.pending[task_id]=pending
  try:
   asyncio.run_coroutine_threadsafe(self.socket.send(json.dumps({'id':task_id,'command':command})),self.loop).result(timeout=3)
   if not pending['event'].wait(40):raise ValueError('Chrome chưa phản hồi; mở Chrome và kiểm tra tiện ích')
   return pending['result']
  finally:
   with self.lock:self.pending.pop(task_id,None)
