# Hynhi Desktop Bridge — Fix79

Cầu nối dùng Wi-Fi/LAN và Chrome đang dùng trên Windows. Bản mặc định đọc văn bản/liên kết và thao tác bằng Windows UI Automation, bàn phím và chuột. Không cần cài hoặc nạp lại tiện ích Chrome, không tạo hồ sơ Chrome mới, không mở cổng gỡ lỗi.

Sau khi đăng nhập Windows, mục khởi động `HynhiDesktopBridge` chạy `start_hidden.pyw`. Có thể cài lại bằng `InstallAutoStart.ps1`; chạy tay bằng `StartHynhiDesktop.cmd`. Nhật ký khởi động ở `.local/startup.log`. Giữ `.local/token` và token đã ghép trên robot; không cần nhập lại. Robot xác minh token đã ghép trước khi bridge nhận địa chỉ IP mới trong LAN. Trang Điều Khiển Máy Tính chỉ hiện trạng thái, tên máy và token dạng che; lệnh dùng giọng nói.

Ví dụ: “Mở YouTube trên máy tính”, “Đọc trang Chrome đang mở”, “Mở bài số hai”, “Tăng âm lượng máy tính”. Để đọc trang, Chrome cần tải và cung cấp vùng nội dung truy cập được. Nếu chọn bài sau khi đổi tab, cầu nối kiểm tra lại đúng liên kết trước khi mở.

Các ghi chú Fix70–78 phía dưới mô tả luồng tiện ích cũ, không phải yêu cầu cài đặt của Fix79.

## Cài đặt

```powershell
python -m venv tools/desktop_bridge/.venv
& tools/desktop_bridge/.venv/Scripts/python.exe -m pip install -r tools/desktop_bridge/requirements.txt
```

Mở `chrome://extensions` trong hồ sơ Chrome thường dùng, bật chế độ nhà phát triển, tải tiện ích đã giải nén từ `chrome_extension`. Mở tùy chọn tiện ích và nhập token từ `.local/token` ngay trên PC. Lưu cùng token trong mục Máy tính trên trang cấu hình robot. Không gửi token vào chat. Sau khi sửa mã tiện ích, bấm Nạp lại trong Chrome.

Mặc định sử dụng Chrome đang dùng thông qua tiện ích, giữ nguyên hồ sơ và các tab. Khi Chrome chưa mở, mở bằng cấu hình mặc định của Windows/Chrome. Chế độ riêng cũ vẫn có thể chọn bằng `--browser-profile isolated`.

Bridge nhớ địa chỉ robot trong `.local/connection.json`. Có thể chỉ định lại:

```powershell
& tools/desktop_bridge/.venv/Scripts/python.exe tools/desktop_bridge/bridge.py --robot-url http://192.168.1.20:8080
```

PC chủ động lấy lệnh từ robot; không cần mở cổng vào Windows Firewall. Cổng điều khiển cục bộ là 8767, tiện ích Chrome kết nối cổng 8766. Đổi IP robot khi router cấp địa chỉ khác.

## Tính năng

- Mở app đã cài, tìm app theo tên; tên trùng cần chọn đúng ứng dụng.
- Mở tab, URL, tìm kiếm, chọn tab, cuộn và đọc toàn trang theo từng phần; gợi ý liên kết theo từ khóa. Trang canvas/iframe khác nguồn có thể không đọc đủ nội dung.
- Quét tên và đường dẫn tệp/thư mục trên ổ cục bộ, danh sách ứng dụng, lối tắt Desktop và taskbar. Dữ liệu nhớ tại `.local/apps.json` và `.local/inventory.sqlite3`. Không đọc toàn bộ nội dung tệp khi lập danh mục; không vượt quyền truy cập Windows. Bỏ qua thư mục không được phép và liên kết có nguy cơ tạo vòng lặp.
- Tìm và mở tài liệu từ kết quả đã lập danh mục; không tự chạy file lệnh. Có nút quét lại/tạm dừng; quét lớn chạy nền để tránh chặn điều khiển.
- Zalo: tìm liên lạc → chọn đúng người → soạn và xem nháp → yêu cầu gửi riêng. Cần Zalo PC đã đăng nhập. Không ghi đè nháp khác; nội dung hoặc người nhận thay đổi sẽ chặn gửi. Xác nhận thao tác gửi trong app không chứng minh người nhận đã nhận/đọc.

Kết quả riêng tư trên robot cần token. Nội dung trang, file và ứng dụng là dữ liệu, không phải chỉ dẫn thực thi. Không chia sẻ hoặc đóng gói thư mục `.local` và `.venv` vào ZIP mã nguồn.

## Fix70: YouTube trên Chrome mặc định

Tiện ích v1.1.0 bổ sung `youtube_search` (từ khóa → danh sách video_id/title), `youtube_play` (từ khóa hoặc JSON `{"video_id":"…","fullscreen":true}`), `media_control` (JSON `operation` và `amount` khi cần). Các thao tác: play, pause, seek (giây tương đối), volume (0–100), mute, unmute, rate (0.25–2), fullscreen, exit_fullscreen, next, captions, status.

Ví dụ nói với robot: “Mở YouTube trên máy tính, tìm và phát video hướng dẫn ESP32 toàn màn hình”, “Tạm dừng video trên PC”, “Tua tới 30 giây”, “Âm lượng video 50”, “Thoát toàn màn hình”. Chỉ nói tìm kiếm thì trả danh sách để chọn; nói tìm và phát thì dùng kết quả đầu. Tên trùng cần chọn lại đúng video.

Từ Fix73, toàn màn hình video dùng phím F thật của YouTube; thoát chỉ gửi F khi trình phát đang toàn màn hình. Cầu nối xác minh đúng tab/cửa sổ và kết quả trước khi báo thành công. Không vượt quảng cáo, đăng nhập, giới hạn tuổi/khu vực hay yêu cầu đồng ý của YouTube. Chrome có thể yêu cầu bấm Phát lần đầu. Cập nhật mã tiện ích cần bấm Nạp lại tại chrome://extensions.

Tham khảo đã đối chiếu (không sao chép toàn bộ server/phần cứng):
- https://github.com/microsoft/playwright-mcp — tự động hóa trình duyệt và dùng hồ sơ đang đăng nhập.
- https://github.com/CursorTouch/Windows-MCP — điều khiển ứng dụng Windows bằng UI Automation.
- https://github.com/lepczynski-cloud/ESP32-PC-Control-Deck — mô hình ESP32 và chương trình đồng hành trên PC (dự án này dùng USB, Hynhi tiếp tục dùng LAN).

RangDongSmart OC.01.WF 16A: chưa liên kết được bằng QR HA hiện tại. Không coi việc tạo QR thành công là ứng dụng OEM đã hỗ trợ. Chưa có API/ủy quyền OEM hoặc local_key của thiết bị; không tự reset hay chuyển ổ cắm khỏi tài khoản đang dùng. TinyTuya là hướng LAN tham khảo nhưng vẫn cần device_id/IP/protocol/local_key, không thay thế cấp quyền: https://github.com/jasonacox/tinytuya.



## Fix73: cửa sổ, tab và ngữ cảnh PC

- Tiện ích Chrome 1.2.0. `fullscreen`/`restore` dùng phím F thật, `media_control` cũng hỗ trợ operation fullscreen/exit_fullscreen qua cùng luồng.
- `app_open`: mở ứng dụng đã cài, đưa đúng cửa sổ lên trước và maximize. Ứng dụng Windows được phóng lớn theo khả năng cửa sổ; không gửi phím F vào các ứng dụng khác.
- `app_close`: tên/app_id cụ thể, hoặc để trống để đóng ứng dụng bridge vừa mở. Gửi yêu cầu đóng cửa sổ, giữ nguyên hộp thoại lưu; không kill tiến trình.
- `close_tab`: chỉ số tab, hoặc để trống để đóng tab bridge đang điều khiển. Không tự đóng mọi tab. Lựa chọn cuối nhớ trong phiên bridge/tiện ích; khởi động lại có thể cần chọn lại.
- Nội dung mở web/ứng dụng không được coi là chỉ dẫn hệ thống. Bridge không tự đọc hoặc gửi tin nhắn khi người dùng chỉ yêu cầu mở/đóng ứng dụng.
