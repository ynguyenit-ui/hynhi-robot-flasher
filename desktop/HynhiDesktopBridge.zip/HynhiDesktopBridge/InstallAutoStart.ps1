$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$python = Join-Path $root '.venv\Scripts\pythonw.exe'
$bridge = Join-Path $root 'start_hidden.pyw'
if (!(Test-Path -LiteralPath $python) -or !(Test-Path -LiteralPath $bridge)) { throw 'Thiếu môi trường cầu nối Hynhi.' }
$workspace = (Resolve-Path -LiteralPath (Join-Path $root '..\..')).Path
$command = '"{0}" "{1}" --browser-profile default --allow-folder "{2}"' -f $python,$bridge,$workspace
$runKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
New-ItemProperty -Path $runKey -Name 'HynhiDesktopBridge' -Value $command -PropertyType String -Force | Out-Null
