@echo off
chcp 65001 >nul
title Cai dat Hynhi Desktop Bridge
echo Dang cai dat Hynhi Desktop Bridge... (can Internet, mat 2-5 phut lan dau)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Cai-Dat.ps1"
echo.
pause
