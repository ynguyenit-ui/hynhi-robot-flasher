# Hynhi Desktop Bridge - cai dat 1 lan, tu chay cung Windows, khong can quyen Admin.
$ErrorActionPreference = 'Stop'
$src = Split-Path -Parent $MyInvocation.MyCommand.Path
$dst = Join-Path $env:LOCALAPPDATA 'HynhiDesktop'
function Find-Python {
  foreach ($c in @(@('py','-3'),@('python'))) {
    try { $v = & $c[0] $c[1..9] -c "import sys;print(sys.version_info[0]*100+sys.version_info[1])" 2>$null
      if ($LASTEXITCODE -eq 0 -and [int]$v -ge 310) { return ,$c } } catch {}
  }
  return $null
}
$py = Find-Python
if (-not $py) {
  Write-Host 'Chua co Python, dang cai Python 3.12 qua winget...'
  winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
  $env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
  $py = Find-Python
  if (-not $py) { throw 'Khong cai duoc Python. Hay cai Python 3.12 tu python.org (tich Add to PATH) roi chay lai Cai-Dat.cmd.' }
}
Write-Host 'Dung Python:' ($py -join ' ')
New-Item -ItemType Directory -Force $dst | Out-Null
Get-ChildItem $src -Exclude '.venv','.local','__pycache__','Cai-Dat.*' | Copy-Item -Destination $dst -Recurse -Force
$venv = Join-Path $dst '.venv'
if (-not (Test-Path (Join-Path $venv 'Scripts\pythonw.exe'))) { & $py[0] $py[1..9] -m venv $venv }
$vpy = Join-Path $venv 'Scripts\python.exe'
& $vpy -m pip install --disable-pip-version-check -q --upgrade pip
& $vpy -m pip install --disable-pip-version-check -q pywinauto comtypes pywin32 websockets pycaw psutil
if ($LASTEXITCODE -ne 0) { throw 'pip loi - kiem tra Internet roi chay lai.' }
$pyw = Join-Path $venv 'Scripts\pythonw.exe'
$cmd = '"{0}" "{1}" --browser-profile default --allow-folder "{2}"' -f $pyw,(Join-Path $dst 'start_hidden.pyw'),$env:USERPROFILE
New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' -Name 'HynhiDesktopBridge' -Value $cmd -PropertyType String -Force | Out-Null
Get-CimInstance Win32_Process -Filter "Name='pythonw.exe'" | Where-Object { $_.CommandLine -like '*start_hidden.pyw*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
Start-Process -FilePath $pyw -ArgumentList ('"{0}" --browser-profile default --allow-folder "{1}"' -f (Join-Path $dst 'start_hidden.pyw'),$env:USERPROFILE) -WindowStyle Hidden
Write-Host ''
Write-Host 'XONG. Bridge dang chay ngam va tu chay moi lan bat may.'
Write-Host 'Robot va may tinh phai cung WiFi. Robot tu ghep noi sau khoang 1 phut (khong can nhap gi).'
Write-Host 'Thu: noi voi robot "Mo YouTube tren may tinh".'
