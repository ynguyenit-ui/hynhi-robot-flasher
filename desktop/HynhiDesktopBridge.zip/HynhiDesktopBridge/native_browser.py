"""Chrome accessibility/keyboard control. No extension, debug port or new profile."""
import ctypes,json,time,uuid,re
from html.parser import HTMLParser
from urllib.parse import quote,urlsplit,urljoin,parse_qs
from windows_apps import open_default_chrome,normalize
from pywinauto import Desktop,keyboard,mouse
from window_control import front_window
from desktop_ui import DesktopUI

def foreground_root():
 user=ctypes.windll.user32;active=user.GetForegroundWindow()
 return user.GetAncestor(active,3) or active

class PageLinks(HTMLParser):
 def __init__(self,base):super().__init__();self.base=base;self.links=[];self.current=None
 def handle_starttag(self,tag,attrs):
  if tag=='a':
   a=dict(attrs);self.current=[urljoin(self.base,a.get('href','')),[],a.get('title','')]
 def handle_data(self,data):
  if self.current:self.current[1].append(data)
 def handle_endtag(self,tag):
  if tag=='a' and self.current:
   url,parts,label=self.current;self.current=None;title=' '.join(' '.join(parts).split()) or label
   if 12<=len(title)<=240:self.links.append((title,url,None))

class NativeBrowser:
 def __init__(self):
  self.handle=None;self.snapshot=None;self.ui=DesktopUI()
  self.ad_window=None
  self.next_ad_check=0
 @staticmethod
 def is_youtube(url):
  parsed=urlsplit(url)
  return parsed.scheme=='https' and parsed.hostname in ('youtube.com','www.youtube.com','m.youtube.com') and not parsed.username and not parsed.password
 def skip_youtube_ad(self):
  now=time.monotonic()
  if self.ad_window is None or now<self.next_ad_check or foreground_root()!=self.ad_window:return
  self.next_ad_check=now+1
  try:
   window=Desktop(backend='uia').window(handle=self.ad_window).wrapper_object()
   if not self.is_chrome(window):return
   document=self.document(window)
   url=self.address(window) or document.legacy_properties().get('Value','')
   if not self.is_youtube(url):return
   names={'bo qua','bo qua quang cao','skip ad','skip ads','skip advertisement'}
   buttons=[button for button in document.descendants(control_type='Button')
            if normalize(button.window_text()) in names and button.is_visible() and button.is_enabled()]
   if len(buttons)==1 and foreground_root()==self.ad_window:
    buttons[0].iface_invoke.Invoke()
  except Exception:
   # The player can replace the advertisement controls between polls.
   return
 @staticmethod
 def is_chrome(w):
  import psutil
  return w.class_name()=='Chrome_WidgetWin_1' and psutil.Process(w.process_id()).name().lower()=='chrome.exe'
 def window(self):
  try:
   active=foreground_root();w=Desktop(backend='uia').window(handle=active).wrapper_object()
   if self.is_chrome(w):self.handle=active;return w
  except Exception:pass
  if self.handle:
   try:
    w=Desktop(backend='uia').window(handle=self.handle).wrapper_object()
    if self.is_chrome(w):
     raised=front_window(w.window_text(),before=())
     if self.is_chrome(raised):return raised
   except Exception:pass
  w=front_window('Google Chrome','google chrome');self.handle=w.handle;return w
 def address(self,w):
  for edit in w.descendants(control_type='Edit'):
   name=normalize(edit.window_text())
   if any(x in name for x in ('address','dia chi','search and','tim kiem va')):
    value=edit.get_value()
    if value and '.' in value:return value if '://' in value else 'https://'+value
  return ''
 def confirmed_address(self,w,force=False):
  address=self.address(w)
  if address and not force:return address
  keyboard.send_keys('^l',vk_packet=False);time.sleep(.16)
  try:
   try:text,_=self.copy_selection(w)
   except Exception:
    if address:return address
    raise
  finally:
   if foreground_root()==w.handle:keyboard.send_keys('{ESC}',vk_packet=False)
  return text.strip() if text.startswith(('http://','https://')) else address
 def copy_selection(self,w):
  import win32clipboard as clipboard
  user=ctypes.windll.user32
  def opened():
   for attempt in range(8):
    try:clipboard.OpenClipboard(w.handle);return
    except Exception:time.sleep(.03)
   raise ValueError('Clipboard đang được ứng dụng khác dùng')
  saved=[];opened()
  try:
   fmt=0
   while True:
    fmt=clipboard.EnumClipboardFormats(fmt)
    if not fmt:break
    # CF_BITMAP is a live handle; Windows can synthesize it again from DIB.
    if fmt==2 and (clipboard.IsClipboardFormatAvailable(8) or clipboard.IsClipboardFormatAvailable(17)):continue
    if fmt>=49152 and clipboard.GetClipboardFormatName(fmt) in ('DataObject','Ole Private Data'):continue
    value=clipboard.GetClipboardData(fmt)
    if not isinstance(value,(bytes,str)):raise ValueError('Clipboard chứa dữ liệu đặc biệt; đọc qua vùng hỗ trợ Windows hoặc thử sau')
    saved.append((fmt,value))
   before=user.GetClipboardSequenceNumber()
  finally:clipboard.CloseClipboard()
  keyboard.send_keys('^c',vk_packet=False);time.sleep(.22)
  if user.GetClipboardSequenceNumber()==before or foreground_root()!=w.handle:return '',''
  opened()
  try:
   text=clipboard.GetClipboardData(clipboard.CF_UNICODETEXT) if clipboard.IsClipboardFormatAvailable(clipboard.CF_UNICODETEXT) else ''
   fmt=clipboard.RegisterClipboardFormat('HTML Format');html=clipboard.GetClipboardData(fmt) if clipboard.IsClipboardFormatAvailable(fmt) else b''
   return text[:180000],html[:1500000].decode('utf-8','replace') if isinstance(html,bytes) else str(html)[:1500000]
  finally:
   try:
    clipboard.EmptyClipboard()
    for fmt,value in saved:clipboard.SetClipboardData(fmt,value)
   finally:clipboard.CloseClipboard()
 def document(self,w):
  docs=[d for d in w.descendants(control_type='Document') if d.is_visible()]
  if not docs:raise ValueError('Chrome chưa có nội dung trang đọc được; chờ tải rồi thử lại')
  import win32gui
  title=win32gui.GetWindowText(w.handle).casefold()
  return next((d for d in docs if d.window_text() and title.startswith(d.window_text().casefold())),docs[0])
 def scan(self,query='',offset=0,verified_url=None):
  w=self.window();url=verified_url or self.confirmed_address(w);text='';candidates=[];doc=None
  if not url:raise ValueError('Chưa xác minh địa chỉ trang đang hiển thị')
  try:
   doc=self.document(w)
   try:doc.set_focus();time.sleep(.15)
   except Exception:pass
   text=doc.iface_text.DocumentRange.GetText(180000) or ''
  except Exception:pass
  if doc:
   for control in doc.descendants(control_type='Hyperlink')[:600]:
    try:
     title=control.window_text().strip()
     if 12<=len(title)<=240:
      target=control.legacy_properties().get('Value','') or ''
      if target.startswith(('https://','http://')):
       candidates.append((title,target,control))
       if len(candidates)>=90:break
    except Exception:pass
  if not text.strip() or not any(target.startswith(('https://','http://')) for _,target,_ in candidates):
   # F6 cycles Chrome's focus areas without clicking unknown page controls.
   for _ in range(5):
    if foreground_root()!=w.handle:raise ValueError('Cửa sổ đổi trong lúc đọc')
    keyboard.send_keys('{F6}',vk_packet=False);time.sleep(.12);keyboard.send_keys('^a',vk_packet=False);plain,html=self.copy_selection(w)
    if html:
     parser=PageLinks(url);parser.feed(html);candidates.extend(parser.links);text=plain or text
     keyboard.send_keys('{ESC}',vk_packet=False);break
  links=[];seen=set()
  for title,target,control in candidates:
   if len(title)<12 or len(title)>240 or target in seen:continue
   parsed=urlsplit(target)
   if parsed.scheme not in ('http','https') or not parsed.netloc or parsed.username or parsed.password or parsed.path.lower().endswith(('.exe','.msi','.zip','.bat','.cmd')):continue
   seen.add(target);links.append({'article_id':uuid.uuid4().hex[:12],'title':title,'control':control,'url':target})
   if len(links)>=60:break
  terms=normalize(query).split();links.sort(key=lambda e:-sum(t in normalize(e['title']) for t in terms));shown=links[:12]
  self.snapshot={'handle':w.handle,'url':url,'title':w.window_text(),'time':time.monotonic(),'text':text,'links':links,'shown':shown}
  return self.result(offset)
 def result(self,offset=0):
  s=self.snapshot;text=s['text'];return {'ok':True,'title':s['title'],'url':s['url'],'text':text[offset:offset+4000],'offset':offset,'total_characters':len(text),'next_offset':offset+4000 if offset+4000<len(text) else None,'articles':[{'article_id':x['article_id'],'title':x['title'],'index':i+1} for i,x in enumerate(s['shown'])],'content_is_untrusted':True,'browser_profile':'default','browser_transport':'windows_accessibility','foreground':True}
 def open(self,url,new=False):
  p=urlsplit(url)
  if len(url)>4096 or any(ord(c)<=32 for c in url) or p.scheme not in ('http','https') or not p.netloc or p.username or p.password:raise ValueError('Cần URL HTTP/HTTPS hợp lệ')
  if new:open_default_chrome(url)
  else:
   try:w=self.window()
   except ValueError:open_default_chrome();w=self.window()
   keyboard.send_keys('^l',vk_packet=False);time.sleep(.15)
   if foreground_root()!=w.handle:raise ValueError('Chrome không còn ở trước')
   from zalo_control import key,emit
   encoded=url.encode('utf-16-le');events=[]
   for i in range(0,len(encoded),2):
    unit=int.from_bytes(encoded[i:i+2],'little');events.extend((key(0,scan=unit,unicode=True),key(0,True,scan=unit,unicode=True)))
   emit(events);keyboard.send_keys('{ENTER}',vk_packet=False)
  self.ad_window=foreground_root() if self.is_youtube(url) else None
  deadline=time.monotonic()+6
  last=None
  while time.monotonic()<deadline:
   time.sleep(.25)
   try:
    window=self.window()
    current=self.confirmed_address(window)
    address=urlsplit(current)
    expected_query=parse_qs(p.query)
    actual_query=parse_qs(address.query)
    if (address.hostname!=p.hostname
        or address.path.rstrip('/')!=p.path.rstrip('/')
        or any(actual_query.get(key)!=value for key,value in expected_query.items())):
     continue
    self.document(window)
    result=self.scan(verified_url=current)
    if result['text'] or result['articles']:
     result['auto_scanned']=True
     return result
   except Exception as error:
    last=error
  raise ValueError('Chrome chưa tải được đúng nội dung yêu cầu'+(': '+str(last) if last else ''))
 def execute(self,command):
  action=command['action'];value=command.get('value','')
  if action in ('open_url','new_tab','search','youtube_search','youtube_play'):
   if action=='search':url='https://www.google.com/search?q='+quote(str(value))
   elif action in ('youtube_search','youtube_play'):
    options=json.loads(value) if str(value).startswith('{') else {'query':str(value)}
    url='https://www.youtube.com/watch?v='+quote(options['video_id']) if options.get('video_id') else 'https://www.youtube.com/results?search_query='+quote(options.get('query',''))
   else:url=value
   result=self.open(url,action=='new_tab')
   if action in ('youtube_search','youtube_play') and not options.get('video_id'):
    videos=[]
    for link in self.snapshot['links']:
     parsed=urlsplit(link['url']);key=parse_qs(parsed.query).get('v',[''])[0]
     if parsed.hostname in ('www.youtube.com','youtube.com','m.youtube.com') and parsed.path=='/watch' and re.fullmatch(r'[\w-]{11}',key):videos.append({'video_id':key,'title':link['title'],'article_id':link['article_id']})
    result['videos']=videos[:12]
   if action=='youtube_play' and not options.get('video_id'):
    if not result['videos']:raise ValueError('Chưa thấy liên kết video đã xác minh; yêu cầu đọc trang để chọn')
    result=self.execute({'action':'article_open','value':result['videos'][0]['article_id']})
   if action=='youtube_play' and options.get('fullscreen',True):result.update(self.media({'operation':'fullscreen'}))
   return result
  if action in ('scan_page','news_scan'):return self.scan(value)
  if action=='read_page':
   offset=max(0,int(value or 0));w=self.window()
   if not self.snapshot or self.snapshot['handle']!=w.handle or self.snapshot['url']!=self.confirmed_address(w,force=True):return self.scan(offset=offset)
   return self.result(offset)
  if action=='article_open':
   s=self.snapshot;w=self.window()
   if not s or not s['url'] or s['handle']!=w.handle or time.monotonic()-s['time']>1200:raise ValueError('Đọc lại trang đang mở trước khi chọn bài')
   matches=[x for x in s['links'] if x['article_id']==value]
   if not matches and str(value).isdigit() and 1<=int(value)<=len(s['shown']):matches=[s['shown'][int(value)-1]]
   if not matches:
    title=normalize(value)
    matches=[link for link in s['links'] if title and normalize(link['title'])==title]
    if not matches:
     matches=[link for link in s['links'] if title and title in normalize(link['title'])]
   if len(matches)!=1:raise ValueError('Tên bài chưa rõ hoặc trùng; chọn số bài hoặc tiêu đề đầy đủ')
   if s['url']!=self.confirmed_address(w):
    raise ValueError('Trang đang mở đã đổi; đọc lại danh sách trước khi chọn bài')
   return self.open(matches[0]['url'])
  if action=='status':
   w=self.window();return {'ok':True,'title':w.window_text(),'url':self.confirmed_address(w),'browser_transport':'windows_accessibility','browser_profile':'default','foreground':True}
  if action=='close_tab':
   self.window()
   if str(value).strip():
    n=int(value)
    if not 0<=n<=7:raise ValueError('Chọn chỉ số tab0..7')
    keyboard.send_keys('^'+str(n+1),vk_packet=False);time.sleep(.2)
   keyboard.send_keys('^w',vk_packet=False);self.snapshot=None;return {'ok':True,'close_requested':True}
  if action=='select_tab':
   n=int(value)
   if not 0<=n<=7:raise ValueError('Chọn chỉ số tab0..7')
   self.window();keyboard.send_keys('^'+str(n+1));return self.scan()
  if action=='scroll':
   w=self.window()
   try:r=self.document(w).rectangle()
   except ValueError:r=w.rectangle()
   mouse.scroll(coords=(r.left+r.width()//2,r.top+r.height()//2),wheel_dist=6 if value=='up' else -6);return {'ok':True}
  if action in ('fullscreen','restore'):return self.media({'operation':'fullscreen' if action=='fullscreen' else 'exit_fullscreen'})
  if action=='media_control':return self.media(json.loads(value))
  raise ValueError('Lệnh trình duyệt chưa hỗ trợ')
 def media(self,values):
  w=self.window();url=self.confirmed_address(w)
  if 'youtube.com/watch' not in url:raise ValueError('Mở đúng video YouTube trước khi điều khiển phát')
  op=values.get('operation');buttons=self.document(w).descendants(control_type='Button')
  aliases={'play':('play','phat'),'pause':('pause','tam dung'),'fullscreen':('full screen','toan man hinh'),'exit_fullscreen':('exit full screen','thoat toan man hinh'),'captions':('subtitles','phu de'),'mute':('mute','tat tieng'),'unmute':('unmute','bat tieng'),'next':('next','tiep theo')}
  if op=='status':return {'ok':True,'title':w.window_text(),'url':url}
  if op not in aliases:raise ValueError('Dùng điều khiển chuột/UIA hoặc âm lượng Windows cho thao tác này')
  matches=[b for b in buttons if any(normalize(b.window_text()).startswith(a) for a in aliases[op])]
  if op=='fullscreen':matches=[b for b in matches if not normalize(b.window_text()).startswith(('exit','thoat'))]
  if len(matches)!=1:raise ValueError('Chưa xác minh duy nhất nút điều khiển trên video')
  try:matches[0].iface_invoke.Invoke()
  except Exception:matches[0].click_input()
  return {'ok':True,'foreground':True,'operation':op}
