"""Verified foreground/window operations and native YouTube F shortcut."""
import ctypes,time,json
from pathlib import Path
from ctypes import wintypes
ctypes.windll.kernel32.OpenProcess.restype=wintypes.HANDLE
ctypes.windll.kernel32.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
ctypes.windll.kernel32.QueryFullProcessImageNameW.argtypes=[wintypes.HANDLE,wintypes.DWORD,wintypes.LPWSTR,ctypes.POINTER(wintypes.DWORD)]
ctypes.windll.kernel32.CloseHandle.argtypes=[wintypes.HANDLE]

def front_window(title,app_id='',before=(),browser_bounds=None):
 from pywinauto import Desktop
 expected=str(title).casefold();hint=str(app_id).casefold();chosen=None
 for _ in range(24):
  candidates=[]
  for w in Desktop(backend='uia').windows():
   try:
    if not w.is_visible() and not ctypes.windll.user32.IsIconic(w.handle):continue
    text=w.window_text().casefold();handle=ctypes.windll.kernel32.OpenProcess(0x1000,False,w.process_id());name=''
    if handle:
     buf=ctypes.create_unicode_buffer(2048);size=ctypes.c_ulong(2048)
     if ctypes.windll.kernel32.QueryFullProcessImageNameW(handle,0,buf,ctypes.byref(size)):name=Path(buf.value).stem.casefold()
     ctypes.windll.kernel32.CloseHandle(handle)
    match=expected and (text==expected or text.startswith(expected+' -'))
    if app_id:match=match or expected==name or ('openai.codex' in hint and name in ['codex','chatgpt']) or ('google chrome'==expected and name=='chrome')
    if browser_bounds and name=='chrome':
     rect=w.rectangle();expected_rect=[browser_bounds.get(k,0) for k in ['left','top','width','height']]
     actual=[rect.left,rect.top,rect.width(),rect.height()]
     if all(abs(a-b)<=12 for a,b in zip(actual,expected_rect)):match=True
    if match:candidates.append(w)
   except Exception:continue
  fresh=[w for w in candidates if w.handle not in before]
  selected=fresh if fresh else candidates
  if len(selected)==1:chosen=selected[0];break
  if len(selected)>1:
   active=[w for w in selected if w.handle==ctypes.windll.user32.GetForegroundWindow()]
   if len(active)==1:chosen=active[0];break
  time.sleep(.2)
 if chosen is None:raise ValueError('Đã mở ứng dụng nhưng chưa xác định duy nhất cửa sổ để đưa lên trước')
 if ctypes.windll.user32.IsIconic(chosen.handle):ctypes.windll.user32.ShowWindow(chosen.handle,9)
 ctypes.windll.user32.ShowWindow(chosen.handle,3)
 try:chosen.set_focus()
 except Exception:pass
 if ctypes.windll.user32.GetForegroundWindow()!=chosen.handle:
  from zalo_control import emit,key
  emit([key(0x12),key(0x12,True)])
  ctypes.windll.user32.BringWindowToTop(chosen.handle);ctypes.windll.user32.SetForegroundWindow(chosen.handle)
 if ctypes.windll.user32.GetForegroundWindow()!=chosen.handle:
  user=ctypes.windll.user32;current=ctypes.windll.kernel32.GetCurrentThreadId()
  foreground=user.GetForegroundWindow();threads={user.GetWindowThreadProcessId(foreground,None),user.GetWindowThreadProcessId(chosen.handle,None)};attached=[]
  # Join only for activation; always detach the temporary input queues.
  try:
   for target in threads:
    if target and target!=current and user.AttachThreadInput(current,target,True):attached.append(target)
   user.ShowWindow(chosen.handle,9);user.ShowWindow(chosen.handle,3)
   user.BringWindowToTop(chosen.handle);user.SetForegroundWindow(chosen.handle)
  finally:
   for target in reversed(attached):user.AttachThreadInput(current,target,False)
 time.sleep(.3)
 if ctypes.windll.user32.GetForegroundWindow()!=chosen.handle:raise ValueError('Windows chưa cho đưa ứng dụng lên trước; chọn cửa sổ trên PC rồi thử lại')
 return chosen

def focus_browser(relay,result=None):
 for attempt in range(3):
  current=relay.execute({'action':'status','value':''})
  if not current.get('ok'):raise ValueError(current.get('error','Chrome chưa phản hồi'))
  title=current.get('tab_title') or current.get('title','')
  try:
   window=front_window(title,browser_bounds=current.get('window_bounds'))
   if result is not None:result.update(foreground=True,window_mode='maximized')
   return window
  except ValueError:
   if attempt==2:raise
   time.sleep(.3)

def video_fullscreen(relay,enabled):
 focused=relay.execute({'action':'media_control','value':json.dumps({'operation':'focus'})})
 if not focused.get('ok'):return focused
 title=focused.get('title','')
 if not title:raise ValueError('Chưa xác minh tab YouTube')
 focus_browser(relay)
 if bool(focused.get('media',{}).get('native_fullscreen'))!=enabled:
  from zalo_control import emit,key
  emit([key(0x46),key(0x46,True)]);time.sleep(.6)
 result=relay.execute({'action':'media_control','value':json.dumps({'operation':'status'})})
 result['fullscreen']=bool(result.get('media',{}).get('native_fullscreen'))
 if result['fullscreen']!=enabled:result.update(ok=False,error='Chưa xác nhận chế độ toàn màn hình F; không gửi phím lặp lại')
 return result
