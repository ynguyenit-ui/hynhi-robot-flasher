@echo off
cd /d "%~dp0"
".venv\Scripts\python.exe" bridge.py --browser-profile default --allow-folder "%USERPROFILE%" --allow-folder "D:\Hynhi_DeskEmoji_Xiaozhi"
