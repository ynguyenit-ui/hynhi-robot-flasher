"""Find an already paired robot without sending the token to unknown LAN peers."""
from concurrent.futures import ThreadPoolExecutor,as_completed
import hashlib,hmac,ipaddress,json,secrets,socket
import re,subprocess
from urllib.parse import urlsplit
from functools import partial
from http.client import HTTPConnection
from urllib.error import HTTPError, URLError
from urllib.request import Request, HTTPHandler, HTTPRedirectHandler, ProxyHandler, build_opener

class DirectHttp(HTTPHandler):
 def __init__(self,source):
  super().__init__()
  self.source=source
 def http_open(self,request):
  connection=partial(HTTPConnection,source_address=(self.source,0)) if self.source else HTTPConnection
  return self.do_open(connection,request)

class NoRedirect(HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs):
  return None

def local_addresses():
 try:
  return list(dict.fromkeys(entry[4][0] for entry in socket.getaddrinfo(socket.gethostname(),None,socket.AF_INET)))
 except OSError:
  return []

_preferred_source={}
def lan_open(request,timeout):
 url=request.full_url if isinstance(request,Request) else request
 host=urlsplit(url).hostname
 destination=ipaddress.IPv4Address(host)
 if not destination.is_private or destination.is_loopback:raise ValueError('Expected a LAN robot')
 subnet=ipaddress.IPv4Network(f'{destination}/24',strict=False)
 candidates=[address for address in local_addresses() if ipaddress.IPv4Address(address) in subnet]
 preferred=[_preferred_source[host]] if host in _preferred_source else []
 sources=list(dict.fromkeys([*preferred,*candidates,None]))
 last_error=None
 for source in sources:
  opener=build_opener(ProxyHandler({}),DirectHttp(source),NoRedirect())
  try:
   response=opener.open(request,timeout=timeout)
   _preferred_source[host]=source
   return response
  except HTTPError:
   # The device replied. Repeating a POST through another adapter is unnecessary.
   _preferred_source[host]=source
   raise
  except (URLError,TimeoutError) as error:
   last_error=error
 raise last_error


def verify(base,token,timeout=.65):
 try:
  url=urlsplit(base);address=ipaddress.ip_address(url.hostname)
  if url.scheme!='http' or not address.is_private or address.is_loopback or url.port!=8080:return False
  nonce=secrets.token_hex(16);expected=hmac.new(token.encode(),nonce.encode(),hashlib.sha256).hexdigest()
  with lan_open(base.rstrip('/')+'/api/desktop/proof?nonce='+nonce,timeout=timeout) as r:
   answer=json.loads(r.read(256)).get('proof','')
  return isinstance(answer,str) and hmac.compare_digest(answer,expected)
 except Exception:return False

def announce(base,name,timeout):
 try:
  with lan_open(base+'/api/desktop',timeout=timeout) as reply:
   status=json.loads(reply.read(4096))
  if not isinstance(status,dict) or status.get('transport')!='wifi_lan' or status.get('auth_required') is not True:return False
  data=json.dumps({'action':'announce','value':name}).encode()
  request=Request(base+'/api/desktop',data=data,headers={'Content-Type':'application/json'})
  with lan_open(request,timeout=timeout) as reply:
   if reply.status!=200:return None
   result=json.loads(reply.read(256))
   token=result.get('pair_token') if isinstance(result,dict) else None
   return token if isinstance(token,str) and len(token)==64 and all(c in '0123456789abcdef' for c in token) else None
 except (OSError,ValueError):return False

def peer_mac(base):
 if not hasattr(__import__('ctypes'),'windll'):return ''
 import ctypes
 try:
  address=socket.inet_aton(urlsplit(base).hostname)
  buffer=(ctypes.c_ubyte*8)()
  host=urlsplit(base).hostname
  subnet=ipaddress.IPv4Network(f'{host}/24',strict=False)
  sources=[value for value in local_addresses() if ipaddress.IPv4Address(value) in subnet]
  for source in dict.fromkeys([_preferred_source.get(host),*sources]):
   size=ctypes.c_ulong(len(buffer))
   source_ip=int.from_bytes(socket.inet_aton(source),'little') if source else 0
   result=ctypes.windll.iphlpapi.SendARP(int.from_bytes(address,'little'),source_ip,ctypes.byref(buffer),ctypes.byref(size))
   if result==0 and size.value==6:return ':'.join(f'{byte:02x}' for byte in buffer[:6])
 except (OSError,TypeError,ValueError):pass
 return ''

def known_neighbors(mac):
 if not mac or not hasattr(subprocess,'CREATE_NO_WINDOW'):return []
 try:
  result=subprocess.run(['arp','-a'],capture_output=True,text=True,timeout=2,
                        creationflags=subprocess.CREATE_NO_WINDOW)
 except (OSError,subprocess.TimeoutExpired):return []
 needle=mac.lower().replace(':','-')
 matches=re.findall(r'^\s*(\d+\.\d+\.\d+\.\d+)\s+([0-9a-f-]{17})',result.stdout,re.M|re.I)
 return list(dict.fromkeys(f'http://{ip}:8080' for ip,hardware in matches if hardware.lower()==needle))

def discover(previous,token,name=None,on_pair=None,pinned_mac=''):
 if previous and verify(previous,token):return previous
 for candidate in known_neighbors(pinned_mac):
  if candidate!=previous and verify(candidate,token,1):return candidate
 addresses=[]
 if previous:
  try:addresses.append(ipaddress.IPv4Address(urlsplit(previous).hostname))
  except ValueError:pass
 try:
  for result in socket.getaddrinfo(socket.gethostname(),None,socket.AF_INET):
   a=ipaddress.IPv4Address(result[4][0]);addresses.append(a)
 except OSError:pass
 # The route socket discovers the current LAN address without sending a packet.
 for destination in ([urlsplit(previous).hostname] if previous else [])+['192.168.1.1','10.0.0.1']:
  try:
   with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as route:
    route.connect((destination,9))
    addresses.insert(0,ipaddress.IPv4Address(route.getsockname()[0]))
  except (OSError,TypeError,ValueError):pass
 networks=list(dict.fromkeys(ipaddress.IPv4Network(f'{a}/24',strict=False) for a in addresses if a.is_private and not a.is_loopback and not a.is_link_local))[:6]
 with ThreadPoolExecutor(max_workers=24) as pool:
  def probe(base):
   if verify(base,token,.35):return True
   if name:
    offered=announce(base,name,.35)
    if offered and on_pair and pinned_mac and peer_mac(base)==pinned_mac and verify(base,offered):
     on_pair(base,offered)
     return True
   return False
  bases=[f'http://{a}:8080' for n in networks for a in n.hosts()]
  futures={pool.submit(probe,base):base for base in bases}
  for f in as_completed(futures):
   if f.result():
    for pending in futures:pending.cancel()
    return futures[f]
 return None
