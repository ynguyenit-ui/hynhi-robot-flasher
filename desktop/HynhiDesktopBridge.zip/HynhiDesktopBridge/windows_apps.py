import ctypes,json,os,subprocess,time,unicodedata,winreg,sys
sys.coinit_flags=2
from pathlib import Path
STATE=Path(__file__).parent/'.local'
def normalize(text):return ' '.join(''.join(c for c in unicodedata.normalize('NFD',str(text).casefold().replace('đ','d')) if not unicodedata.combining(c)).split())
def chrome_exe():
 for hive in [winreg.HKEY_CURRENT_USER,winreg.HKEY_LOCAL_MACHINE]:
  try:
   with winreg.OpenKey(hive,r'SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe') as key:
    path=winreg.QueryValueEx(key,None)[0]
    if Path(path).is_file():return path
  except OSError:pass
 for root in [os.environ.get('PROGRAMFILES',''),os.environ.get('PROGRAMFILES(X86)',''),os.environ.get('LOCALAPPDATA','')]:
  path=Path(root)/'Google/Chrome/Application/chrome.exe'
  if path.is_file():return str(path)
 raise ValueError('Chưa tìm thấy Google Chrome đã cài')
def open_default_chrome(url=None):
 args=[chrome_exe()]
 if url:args.append(url)
 subprocess.Popen(args,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
 from window_control import front_window
 front_window('Google Chrome','google chrome')
 return {'ok':True,'foreground':True,'window_mode':'maximized','browser_profile':'default','url':url or '', 'notice':'Đã mở Chrome với hồ sơ mặc định/đang dùng của Chrome'}
def shortcuts():
 import win32com.client
 shell=win32com.client.Dispatch('WScript.Shell');desktop=Path(shell.SpecialFolders('Desktop'));public=Path(os.environ.get('PUBLIC','C:/Users/Public'))/'Desktop';taskbar=Path(os.environ['APPDATA'])/'Microsoft/Internet Explorer/Quick Launch/User Pinned/TaskBar';results=[]
 for source,root in [('desktop',desktop),('desktop',public),('taskbar',taskbar)]:
  if not root.exists():continue
  for path in root.iterdir():
   item={'name':path.stem,'path':str(path),'source':source}
   if path.suffix.lower()=='.lnk':
    try:
     link=shell.CreateShortcut(str(path));item.update(target=link.TargetPath,arguments=link.Arguments)
    except Exception:pass
   results.append(item)
 return results
def installed_registry():
 results=[];seen=set()
 for hive in [winreg.HKEY_CURRENT_USER,winreg.HKEY_LOCAL_MACHINE]:
  for view in [winreg.KEY_WOW64_64KEY,winreg.KEY_WOW64_32KEY]:
   try:
    with winreg.OpenKey(hive,r'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',0,winreg.KEY_READ|view) as root:
     for i in range(winreg.QueryInfoKey(root)[0]):
      try:
       with winreg.OpenKey(root,winreg.EnumKey(root,i)) as key:
        name=winreg.QueryValueEx(key,'DisplayName')[0]
        if not name or normalize(name) in seen:continue
        item={'name':name,'source':'installed_registry','launchable':False}
        for k,label in [('DisplayVersion','version'),('InstallLocation','install_location')]:
         try:item[label]=winreg.QueryValueEx(key,k)[0]
         except OSError:pass
        seen.add(normalize(name));results.append(item)
      except OSError:pass
   except OSError:pass
 return results
class AppCatalog:
 def __init__(self):self.last_opened=None;self.apps=[];self.installed=[];self.last_refresh=0;self.refresh()
 def refresh(self):
  command='[Console]::OutputEncoding=[System.Text.UTF8Encoding]::new($false); Get-StartApps | Select-Object Name,AppID | ConvertTo-Json -Compress'
  proc=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',command],capture_output=True,timeout=20,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
  data=json.loads(proc.stdout.decode('utf-8-sig',errors='replace'))
  if isinstance(data,dict):data=[data]
  self.apps=[{'name':x['Name'],'app_id':x['AppID']} for x in data if x.get('Name') and x.get('AppID')];self.installed=installed_registry();self.last_refresh=time.time();STATE.mkdir(exist_ok=True);(STATE/'apps.json').write_text(json.dumps({'apps':self.apps,'installed':self.installed,'shortcuts':shortcuts(),'updated':self.last_refresh},ensure_ascii=False),encoding='utf-8');return self.apps
 def find(self,query):
  key=normalize(query);exact=[a for a in self.apps if normalize(a['name'])==key or a['app_id']==query]
  return exact or [a for a in self.apps if key in normalize(a['name'])][:20]
 def open(self,query):
  matches=self.find(query)
  if not matches:raise ValueError('Không tìm thấy ứng dụng trong danh sách đã cài')
  if len(matches)!=1:return {'ok':False,'choose_app':matches,'error':'Có nhiều ứng dụng trùng tên; chọn app_id cụ thể'}
  item=matches[0]
  self.last_opened=item
  if normalize(item['name'])=='google chrome':return open_default_chrome()
  from pywinauto import Desktop
  before={w.handle for w in Desktop(backend='uia').windows()}
  subprocess.Popen(['explorer.exe','shell:AppsFolder\\'+item['app_id']],creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
  from window_control import front_window
  front_window(item['name'],item['app_id'],before)
  return {'ok':True,'app':item['name'],'app_id':item['app_id'],'foreground':True,'window_mode':'maximized'}
 def close(self,query=''):
  item=self.last_opened if not str(query).strip() else None
  if item is None:
   matches=self.find(query)
   if len(matches)!=1:return {'ok':False,'error':'Chọn ứng dụng cụ thể để đóng','choose_app':matches}
   item=matches[0]
  if item is None:raise ValueError('Chưa có ứng dụng vừa mở; nói rõ tên ứng dụng cần đóng')
  from window_control import front_window
  window=front_window(item['name'],item['app_id'])
  ctypes.windll.user32.PostMessageW(window.handle,0x10,0,0)
  time.sleep(.8);closed=not bool(ctypes.windll.user32.IsWindow(window.handle))
  if closed and self.last_opened==item:self.last_opened=None
  return {'ok':True,'app':item['name'],'close_requested':True,'closed_verified':closed,'notice':'Đã đóng cửa sổ' if closed else 'Đã yêu cầu đóng; kiểm tra hộp thoại lưu/xác nhận trên PC, không ép tắt'}
 def taskbar(self):
  from pywinauto import Desktop
  result=[]
  for bar in Desktop(backend='uia').windows(class_name='Shell_TrayWnd'):
   for control in bar.descendants(control_type='Button'):
    try:
     name=control.window_text()
     if name:result.append({'name':name[:120],'automation_id':control.element_info.automation_id})
    except Exception:pass
  return result[:60]
