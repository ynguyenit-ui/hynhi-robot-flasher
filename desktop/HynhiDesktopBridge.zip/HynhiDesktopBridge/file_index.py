"""Persistent metadata index: names/paths only, never file contents or ACL changes."""
import argparse, ctypes,contextlib, hashlib, json, os, re, shutil, sqlite3, subprocess, sys, time, unicodedata
from pathlib import Path
STATE=Path(__file__).parent/'.local'; DB=STATE/'inventory.sqlite3'
def fold(text):return ''.join(c for c in unicodedata.normalize('NFD',str(text).lower().replace('đ','d')) if not unicodedata.combining(c))
def connect():
 STATE.mkdir(exist_ok=True);db=sqlite3.connect(DB,timeout=10);db.execute('PRAGMA journal_mode=WAL');db.execute('PRAGMA synchronous=NORMAL')
 db.executescript('''CREATE TABLE IF NOT EXISTS entries(id INTEGER PRIMARY KEY,path TEXT UNIQUE,name TEXT,folded TEXT,is_dir INTEGER,size INTEGER,mtime REAL,source TEXT DEFAULT 'file');
 CREATE TABLE IF NOT EXISTS queue(path TEXT PRIMARY KEY,active INTEGER DEFAULT 0,priority INTEGER DEFAULT 0);
 CREATE TABLE IF NOT EXISTS done(path TEXT PRIMARY KEY);
 CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT);
 CREATE INDEX IF NOT EXISTS entries_folded ON entries(folded);
 CREATE VIRTUAL TABLE IF NOT EXISTS names USING fts5(folded,content=entries,content_rowid=id);
 CREATE TRIGGER IF NOT EXISTS names_insert AFTER INSERT ON entries BEGIN INSERT INTO names(rowid,folded)VALUES(new.id,new.folded);END;
 CREATE TRIGGER IF NOT EXISTS names_delete AFTER DELETE ON entries BEGIN INSERT INTO names(names,rowid,folded)VALUES('delete',old.id,old.folded);END;
 CREATE TRIGGER IF NOT EXISTS names_update AFTER UPDATE OF folded ON entries BEGIN INSERT INTO names(names,rowid,folded)VALUES('delete',old.id,old.folded);INSERT INTO names(rowid,folded)VALUES(new.id,new.folded);END;''');
 try:db.execute('ALTER TABLE queue ADD COLUMN priority INTEGER DEFAULT 0')
 except sqlite3.OperationalError:pass
 db.execute('CREATE INDEX IF NOT EXISTS queue_priority ON queue(active,priority DESC)');return db
@contextlib.contextmanager
def session():
 db=connect()
 try:yield db;db.commit()
 except Exception:db.rollback();raise
 finally:db.close()
def setting(db,key,default=''):
 row=db.execute('SELECT value FROM meta WHERE key=?',(key,)).fetchone();return row[0] if row else default
def save(db,key,value):db.execute('INSERT OR REPLACE INTO meta(key,value)VALUES(?,?)',(key,str(value)))
def roots():
 if os.name!='nt':return [str(Path.home())]
 mask=ctypes.windll.kernel32.GetLogicalDrives();return [chr(65+i)+':\\' for i in range(26) if mask&(1<<i) and ctypes.windll.kernel32.GetDriveTypeW(chr(65+i)+':\\')==3]
def status():
 with session() as db:
  return {'files':db.execute('SELECT count(*) FROM entries WHERE is_dir=0').fetchone()[0],'folders':db.execute('SELECT count(*) FROM entries WHERE is_dir=1').fetchone()[0],'queued_folders':db.execute('SELECT count(*) FROM queue').fetchone()[0],'running':time.time()-float(setting(db,'heartbeat','0'))<15,'paused':setting(db,'paused')=='1','current_folder':setting(db,'current_folder'),'denied_folders':int(setting(db,'denied','0')),'updated_at':setting(db,'heartbeat'),'complete':setting(db,'complete')=='1','roots':json.loads(setting(db,'roots','[]'))}
def search(query,limit=20):
 query=str(query).strip()[:300];tokens=re.findall(r'\w+',fold(query))[:8]
 if not tokens:raise ValueError('Nhập tên file hoặc thư mục cần tìm')
 expression=' AND '.join('"'+t+'"*' for t in tokens)
 with session() as db:
  rows=db.execute('SELECT e.id,e.name,e.path,e.is_dir,e.size,e.source FROM names n JOIN entries e ON e.id=n.rowid WHERE names MATCH ? ORDER BY length(e.name),e.name LIMIT ?',(expression,min(int(limit),30))).fetchall()
 return [{'id':r[0],'name':r[1],'path':r[2],'is_dir':bool(r[3]),'size':r[4],'source':r[5]} for r in rows]
def item(item_id):
 with session() as db:
  r=db.execute('SELECT path,is_dir FROM entries WHERE id=?',(int(item_id),)).fetchone()
 if not r:raise ValueError('Không tìm thấy file trong chỉ mục')
 return Path(r[0]),bool(r[1])
def start():
 with session() as db:
  save(db,'paused','0')
  if setting(db,'complete')=='1' and not db.execute('SELECT 1 FROM queue LIMIT 1').fetchone():
   db.execute('DELETE FROM done');save(db,'complete','0')
   db.executemany('INSERT OR IGNORE INTO queue(path)VALUES(?)',[(p,) for p in roots()])
  db.commit()
 if not status()['running']:
  subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'--scan'],creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0),stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 return status()
def pause():
 with session() as db:save(db,'paused','1');db.commit()
 return status()
def scan(custom_roots=None):
 mutex=None
 if os.name=='nt':
  name='Local\\HynhiIndex-'+hashlib.sha256(str(DB.resolve()).encode()).hexdigest()[:16]
  kernel=ctypes.windll.kernel32
  kernel.CreateMutexW.argtypes=[ctypes.c_void_p,ctypes.c_bool,ctypes.c_wchar_p];kernel.CreateMutexW.restype=ctypes.c_void_p
  kernel.GetCurrentThread.restype=ctypes.c_void_p;kernel.SetThreadPriority.argtypes=[ctypes.c_void_p,ctypes.c_int]
  kernel.CloseHandle.argtypes=[ctypes.c_void_p]
  mutex=kernel.CreateMutexW(None,True,name)
  if ctypes.windll.kernel32.GetLastError()==183:return
  ctypes.windll.kernel32.SetThreadPriority(ctypes.windll.kernel32.GetCurrentThread(),0x10000)
 db=connect();scan_roots=custom_roots or roots();save(db,'roots',json.dumps(scan_roots));db.execute('UPDATE queue SET active=0')
 if not db.execute('SELECT 1 FROM queue LIMIT 1').fetchone() and setting(db,'complete')!='1':db.executemany('INSERT OR IGNORE INTO queue(path)VALUES(?)',[(p,) for p in scan_roots])
 
 if db.execute('SELECT 1 FROM queue LIMIT 1').fetchone():save(db,'complete','0')
 db.commit();denied=int(setting(db,'denied','0'));last_commit=0
 try:
  while True:
   save(db,'heartbeat',time.time())
   if setting(db,'paused')=='1':db.commit();time.sleep(1);continue
   row=db.execute('SELECT path,priority FROM queue WHERE active=0 ORDER BY priority DESC LIMIT 1').fetchone()
   if not row:save(db,'complete','1');save(db,'current_folder','');db.commit();break
   directory=row[0];priority=row[1];
   if db.execute('SELECT 1 FROM done WHERE path=?',(directory,)).fetchone():db.execute('DELETE FROM queue WHERE path=?',(directory,));db.commit();continue
   db.execute('UPDATE queue SET active=1 WHERE path=?',(directory,));save(db,'current_folder',directory);db.commit()
   if shutil.disk_usage(STATE).free<256*1024*1024:save(db,'paused','1');save(db,'reason','Thiếu chỗ trống cho chỉ mục');db.execute('UPDATE queue SET active=0 WHERE path=?',(directory,));db.commit();continue
   try:
    batch=[];subdirs=[]
    with os.scandir(directory) as entries:
     for entry in entries:
      try:
       info=entry.stat(follow_symlinks=False);is_dir=entry.is_dir(follow_symlinks=False);reparse=getattr(info,'st_reparse_tag',0)
       traverse=is_dir and not entry.is_symlink() and reparse not in (0xA0000003,0xA000000C)
       batch.append((entry.path,entry.name,fold(entry.name),int(is_dir),info.st_size,info.st_mtime))
       if traverse:subdirs.append((entry.path,priority))
       if len(batch)>=500:
        db.executemany('INSERT INTO entries(path,name,folded,is_dir,size,mtime)VALUES(?,?,?,?,?,?) ON CONFLICT(path)DO UPDATE SET name=excluded.name,folded=excluded.folded,is_dir=excluded.is_dir,size=excluded.size,mtime=excluded.mtime WHERE entries.mtime<>excluded.mtime OR entries.size<>excluded.size OR entries.folded<>excluded.folded',batch);db.executemany('INSERT OR IGNORE INTO queue(path,priority)VALUES(?,?)',subdirs);batch=[];subdirs=[];save(db,'heartbeat',time.time());db.commit();time.sleep(.01)
      except (OSError,PermissionError):continue
    if batch:db.executemany('INSERT INTO entries(path,name,folded,is_dir,size,mtime)VALUES(?,?,?,?,?,?) ON CONFLICT(path)DO UPDATE SET name=excluded.name,folded=excluded.folded,is_dir=excluded.is_dir,size=excluded.size,mtime=excluded.mtime WHERE entries.mtime<>excluded.mtime OR entries.size<>excluded.size OR entries.folded<>excluded.folded',batch)
    db.executemany('INSERT OR IGNORE INTO queue(path,priority)VALUES(?,?)',subdirs)
   except (OSError,PermissionError):denied+=1;save(db,'denied',denied)
   db.execute('INSERT OR IGNORE INTO done(path)VALUES(?)',(directory,));db.execute('DELETE FROM queue WHERE path=?',(directory,));save(db,'heartbeat',time.time());db.commit();time.sleep(.001)
 finally:
  save(db,'heartbeat','0');db.commit();db.close()
  if mutex:ctypes.windll.kernel32.CloseHandle(mutex)
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--scan',action='store_true');args=parser.parse_args()
 if args.scan:scan()
