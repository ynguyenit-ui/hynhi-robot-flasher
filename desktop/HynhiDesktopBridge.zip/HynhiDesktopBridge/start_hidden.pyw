"""Hidden logon entry; retain startup errors when Python has no console."""
import os,runpy,sys
from pathlib import Path
root=Path(__file__).resolve().parent
state=root/'.local';state.mkdir(exist_ok=True)
log=state/'startup.log'
sys.stdout=sys.stderr=log.open('a',encoding='utf-8',buffering=1)
sys.stdin=open(os.devnull,encoding='utf-8')
sys.path.insert(0,str(root))
runpy.run_path(str(root/'bridge.py'),run_name='__main__')
