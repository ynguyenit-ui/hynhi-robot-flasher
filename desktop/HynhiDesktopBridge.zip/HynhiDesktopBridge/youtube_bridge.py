#!/usr/bin/env python3
"""Hynhi YouTube bridge: lets the robot play YouTube (video on TFT + audio on speaker).

Runs on the PC (same Wi-Fi as the robot). Needs: python 3.9+, yt-dlp, ffmpeg in PATH.
  pip install -U yt-dlp        (ffmpeg: winget install Gyan.FFmpeg)
Endpoints (LAN only, robot ip filter optional with --robot-ip):
  /yt/search?q=...   -> {"id","title"}
  /yt/video?id=...   -> repeated [uint32 big-endian length][JPEG 240x240] at ~10 fps
  /yt/audio?id=...   -> audio/mpeg stream
"""
import argparse, ipaddress, json, os, re, shutil, subprocess, tempfile, textwrap, threading, time, urllib.parse, urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

ID_RE = re.compile(r'^[A-Za-z0-9_-]{11}$')
URL_ID_RE = re.compile(r'(?:v=|youtu\.be/|shorts/)([A-Za-z0-9_-]{11})')
FPS = 10
_cache, _lock = {}, threading.Lock()
ROBOT_IP = None


def run(cmd, timeout=40):
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, encoding='utf-8', errors='replace')


def search(q):
    m = URL_ID_RE.search(q) or (ID_RE.match(q) and ID_RE.match(q))
    target = ('https://www.youtube.com/watch?v=' + (m.group(1) if m.lastindex else q)) if m else 'ytsearch1:' + q
    r = run(['yt-dlp', '--no-playlist', '--skip-download', '--print', '%(id)s\t%(title)s', target])
    line = (r.stdout.strip().splitlines() or [''])[0]
    vid, _, title = line.partition('\t')
    if not ID_RE.match(vid):
        raise RuntimeError(r.stderr.strip()[-200:] or 'khong tim thay')
    return vid, title


def direct_url(vid):
    with _lock:
        hit = _cache.get(vid)
        if hit and time.time() - hit[1] < 300:
            return hit[0]
    r = run(['yt-dlp', '--no-playlist', '-g', '-f', 'best[height<=360][ext=mp4]/best[height<=480]/best',
             'https://www.youtube.com/watch?v=' + vid])
    url = (r.stdout.strip().splitlines() or [''])[0]
    if not url.startswith('http'):
        raise RuntimeError(r.stderr.strip()[-200:] or 'khong lay duoc luong')
    with _lock:
        _cache[vid] = (url, time.time())
    return url


def split_jpegs(buf):
    """Yield complete JPEG frames from a growing bytearray (consumes them)."""
    while True:
        s = buf.find(b'\xff\xd8')
        if s < 0:
            del buf[:]
            return
        e = buf.find(b'\xff\xd9', s + 2)
        if e < 0:
            del buf[:s]
            return
        yield bytes(buf[s:e + 2])
        del buf[:e + 2]


FONT_REG = r'C:\Windows\Fonts\segoeui.ttf'
FONT_BOLD = r'C:\Windows\Fonts\segoeuib.ttf'
PALETTE = ['0x1F3A5F', '0x3A2A5C', '0x1E4D3C', '0x5A2F3A', '0x4A4220', '0x24485A']


def http_json(url, timeout=12):
    req = urllib.request.Request(url, headers={'User-Agent': 'HynhiBridge/1.0 (desk robot)'})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode('utf-8'))


def wiki(query, lang):
    """Title, short extract and thumbnail URL from Wikipedia (tries lang, then the other language)."""
    for lg in dict.fromkeys([lang, 'en' if lang == 'vi' else 'vi']):
        url = (f'https://{lg}.wikipedia.org/w/api.php?action=query&format=json&formatversion=2&generator=search'
               f'&gsrnamespace=0&gsrlimit=1&prop=extracts%7Cpageimages&exintro=1&explaintext=1&exchars=420'
               f'&piprop=thumbnail&pithumbsize=600&gsrsearch=' + urllib.parse.quote(query))
        try:
            pages = http_json(url).get('query', {}).get('pages', [])
        except Exception:  # noqa: BLE001
            continue
        if pages and pages[0].get('extract'):
            pg = pages[0]
            return pg.get('title', query), pg['extract'].strip(), (pg.get('thumbnail') or {}).get('source', '')
    raise RuntimeError('khong co du lieu')


def make_card(query, lang):
    """240x240 JPEG: picture on top, coloured panel with title and intro underneath (needs ffmpeg + Segoe UI)."""
    title, extract, img_url = wiki(query, lang)
    first = re.split(r'(?<=[.!?])\s', extract)[0]
    lines = textwrap.wrap(first, 30)[:4]
    tmp = tempfile.mkdtemp(prefix='hynhi_card_')
    try:
        src = os.path.join(tmp, 'src.img')
        has_img = False
        if img_url:
            try:
                req = urllib.request.Request(img_url, headers={'User-Agent': 'HynhiBridge/1.0 (desk robot)'})
                with urllib.request.urlopen(req, timeout=12) as r, open(src, 'wb') as f:
                    f.write(r.read())
                has_img = True
            except Exception:  # noqa: BLE001
                pass
        tfile, bfile = os.path.join(tmp, 't.txt'), os.path.join(tmp, 'b.txt')
        open(tfile, 'w', encoding='utf-8').write(title[:28])
        open(bfile, 'w', encoding='utf-8').write('\n'.join(lines))
        color = PALETTE[sum(map(ord, title)) % len(PALETTE)]
        esc = lambda p: p.replace('\\', '/').replace(':', '\\:')
        vf = ('scale=240:150:force_original_aspect_ratio=increase,crop=240:150,pad=240:240:0:0:black,'
              f'drawbox=x=0:y=150:w=240:h=90:color={color}:t=fill,drawbox=x=0:y=150:w=240:h=4:color=0xFFB454:t=fill,'
              f"drawtext=fontfile='{esc(FONT_BOLD)}':textfile='{esc(tfile)}':fontcolor=0xFFE58A:fontsize=22:x=10:y=157,"
              f"drawtext=fontfile='{esc(FONT_REG)}':textfile='{esc(bfile)}':fontcolor=white:fontsize=13:line_spacing=2:x=10:y=185")
        out = os.path.join(tmp, 'card.jpg')
        if has_img:
            cmd = ['ffmpeg', '-loglevel', 'error', '-y', '-i', src, '-vf', vf, '-frames:v', '1', '-q:v', '6', out]
        else:
            cmd = ['ffmpeg', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', f'color=c={color}:s=240x240', '-vf',
                   vf.split(',', 3)[3], '-frames:v', '1', '-q:v', '6', out]
        r = run(cmd, 30)
        if not os.path.exists(out):
            raise RuntimeError(r.stderr.strip()[-200:] or 'ffmpeg loi')
        return open(out, 'rb').read()
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


class Handler(BaseHTTPRequestHandler):
    server_version = 'HynhiYT/1'

    def log_message(self, *a):
        pass

    def allowed(self):
        ip = ipaddress.ip_address(self.client_address[0])
        if ROBOT_IP:
            return self.client_address[0] == ROBOT_IP
        return ip.is_private or ip.is_loopback

    def do_GET(self):
        if not self.allowed():
            return self.send_error(403)
        u = urlsplit(self.path)
        q = parse_qs(u.query)
        try:
            if u.path == '/yt/search':
                vid, title = search(q.get('q', [''])[0][:120])
                body = json.dumps({'id': vid, 'title': title[:80]}, ensure_ascii=False).encode()
                self.send_response(200); self.send_header('Content-Type', 'application/json; charset=utf-8')
                self.send_header('Content-Length', str(len(body))); self.end_headers(); self.wfile.write(body)
            elif u.path == '/card':
                jpg = make_card(q.get('q', [''])[0][:80], 'en' if q.get('lang', ['vi'])[0] == 'en' else 'vi')
                self.send_response(200); self.send_header('Content-Type', 'image/jpeg')
                self.send_header('Content-Length', str(len(jpg))); self.end_headers(); self.wfile.write(jpg)
            elif u.path in ('/yt/video', '/yt/audio'):
                vid = q.get('id', [''])[0]
                if not ID_RE.match(vid):
                    return self.send_error(400)
                src = direct_url(vid)
                video = u.path == '/yt/video'
                if video:
                    cmd = ['ffmpeg', '-loglevel', 'error', '-re', '-i', src, '-an', '-vf',
                           f'fps={FPS},scale=240:240:force_original_aspect_ratio=decrease,pad=240:240:(ow-iw)/2:(oh-ih)/2',
                           '-q:v', '7', '-f', 'image2pipe', '-vcodec', 'mjpeg', '-']
                else:
                    cmd = ['ffmpeg', '-loglevel', 'error', '-re', '-i', src, '-vn', '-c:a', 'libmp3lame',
                           '-b:a', '96k', '-ar', '44100', '-ac', '2', '-f', 'mp3', '-']
                self.send_response(200)
                self.send_header('Content-Type', 'application/octet-stream' if video else 'audio/mpeg')
                self.send_header('Connection', 'close'); self.end_headers()
                p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
                try:
                    buf = bytearray()
                    while True:
                        chunk = p.stdout.read(8192 if video else 4096)
                        if not chunk:
                            break
                        if video:
                            buf += chunk
                            for jpg in split_jpegs(buf):
                                self.wfile.write(len(jpg).to_bytes(4, 'big') + jpg)
                        else:
                            self.wfile.write(chunk)
                finally:
                    p.kill()
            else:
                self.send_error(404)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:  # noqa: BLE001
            try:
                self.send_error(502, str(e)[:100].replace('\n', ' '))
            except Exception:
                pass


def main():
    global ROBOT_IP
    ap = argparse.ArgumentParser()
    ap.add_argument('--port', type=int, default=8768)
    ap.add_argument('--robot-ip', default=None, help='only accept this robot IP')
    a = ap.parse_args()
    ROBOT_IP = a.robot_ip
    for tool in ('yt-dlp', 'ffmpeg'):
        if not shutil.which(tool):
            print(f'THIEU {tool}: cai dat roi chay lai'); return
    print(f'Hynhi YouTube bridge: cong {a.port}')
    ThreadingHTTPServer(('0.0.0.0', a.port), Handler).serve_forever()


if __name__ == '__main__':
    main()
