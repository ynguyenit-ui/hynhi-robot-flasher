@echo off
cd /d %~dp0
python youtube_bridge.py
pause
