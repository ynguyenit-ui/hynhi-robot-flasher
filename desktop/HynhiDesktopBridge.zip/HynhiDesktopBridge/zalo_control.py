"""Zalo UI Automation. Search/select/draft/send are separate operations."""
import ctypes,hashlib,json,time,uuid
from ctypes import wintypes
from windows_apps import normalize
class KEYBDINPUT(ctypes.Structure):_fields_=[('vk',wintypes.WORD),('scan',wintypes.WORD),('flags',wintypes.DWORD),('time',wintypes.DWORD),('extra',ctypes.c_size_t)]
class MOUSEINPUT(ctypes.Structure):_fields_=[('dx',wintypes.LONG),('dy',wintypes.LONG),('data',wintypes.DWORD),('flags',wintypes.DWORD),('time',wintypes.DWORD),('extra',ctypes.c_size_t)]
class HARDWAREINPUT(ctypes.Structure):_fields_=[('message',wintypes.DWORD),('low',wintypes.WORD),('high',wintypes.WORD)]
class INPUT_UNION(ctypes.Union):_fields_=[('keyboard',KEYBDINPUT),('mouse',MOUSEINPUT),('hardware',HARDWAREINPUT)]
class INPUT(ctypes.Structure):_anonymous_=('body',);_fields_=[('kind',wintypes.DWORD),('body',INPUT_UNION)]
def key(vk,up=False,scan=0,unicode=False):return INPUT(kind=1,keyboard=KEYBDINPUT(vk,scan,(4 if unicode else 0)|(2 if up else 0),0,0))
def emit(inputs):
 array=(INPUT*len(inputs))(*inputs);send=ctypes.windll.user32.SendInput;send.argtypes=[wintypes.UINT,ctypes.POINTER(INPUT),ctypes.c_int];send.restype=wintypes.UINT
 if send(len(inputs),array,ctypes.sizeof(INPUT))!=len(inputs):raise ValueError('Windows không nhận bàn phím; kiểm tra cửa sổ ứng dụng')
class ZaloControl:
 def __init__(self,catalog):self.catalog=catalog;self.candidates={};self.selected=None;self.draft=None
 def window(self,focus=True):
  from pywinauto import Desktop
  matches=[w for w in Desktop(backend='uia').windows() if w.window_text()=='Zalo']
  if not matches:
   self.catalog.open('Zalo')
   for _ in range(30):
    time.sleep(.2);matches=[w for w in Desktop(backend='uia').windows() if w.window_text()=='Zalo']
    if matches:break
  if not matches:raise ValueError('Chưa mở được Zalo; mở và đăng nhập trên PC trước')
  w=matches[0]
  if focus:
   if ctypes.windll.user32.IsIconic(w.handle):ctypes.windll.user32.ShowWindow(w.handle,9)
   w.set_focus()
   time.sleep(.5)
  return w
 def control(self,w,identifier):
  from pywinauto import Desktop
  spec=Desktop(backend='uia').window(handle=w.handle).child_window(auto_id=identifier)
  if not spec.exists(timeout=2):raise ValueError('Zalo chưa có điều khiển '+identifier+'; kiểm tra đăng nhập hoặc phiên bản ứng dụng')
  return spec.wrapper_object()
 def header_matches(self,w,name):
  view=self.control(w,'chatViewContainer').rectangle();document=self.control(w,'chatView').rectangle()
  for text in w.descendants(control_type='Text'):
   try:
    rect=text.rectangle()
    if rect.left>=view.left-2 and rect.top>=view.top-2 and rect.bottom<=document.top+3 and normalize(text.window_text())==normalize(name):return True
   except Exception:pass
  return False
 def find(self,query):
  query=str(query).strip()
  if not 1<=len(query)<=100:raise ValueError('Tên liên lạc chưa hợp lệ')
  w=self.window();search=self.control(w,'contact-search-input');search.set_focus();search.iface_value.SetValue(query);time.sleep(.8)
  minimum=search.rectangle().bottom
  for control in w.descendants(control_type='Text'):
   rect=control.rectangle()
   if minimum<rect.top<minimum+60 and normalize(control.window_text())=='lien he':
    control.click_input();break
  time.sleep(1)
  sidebar=self.control(w,'sidebarNav').rectangle();self.candidates={};found=[];rows={}
  result_table=self.control(w,'global_search_list')
  for control in result_table.descendants(control_type='Text'):
   try:
    rect=control.rectangle()
    if rect.left<sidebar.left+65 or rect.right>sidebar.right+3 or rect.top<minimum+60 or rect.bottom>sidebar.bottom or rect.height()>45:continue
    name=control.window_text().strip()
    if not name or len(name)>120:continue
    line=next((y for y in rows if abs(y-rect.top)<=2),rect.top)
    rows.setdefault(line,[]).append((rect.left,control,name))
   except Exception:continue
  for top,parts in sorted(rows.items()):
   parts.sort(key=lambda p:p[0]);name=' '.join(p[2] for p in parts)
   if parts[0][0]>search.rectangle().left+70:continue
   if normalize(query) not in normalize(name) or len(name)>150:continue
   token=uuid.uuid4().hex[:12];self.candidates[token]={'element':parts[0][1],'parts':[(p[1],p[2]) for p in parts],'name':name,'query':query,'created':time.time()};found.append({'contact_id':token,'name':name})
   if len(found)>=20:break
  self.selected=None;self.draft=None
  return {'ok':True,'contacts':found,'query':query,'requires_selection':True,'notice':'Chọn đúng liên lạc; nếu trùng tên cần bạn xác định lại. Chưa soạn hoặc gửi tin.'}
 def select(self,contact_id):
  entry=self.candidates.get(str(contact_id))
  if not entry or time.time()-entry['created']>300:raise ValueError('Kết quả tìm kiếm hết hạn; tìm lại liên lạc')
  w=self.window();search=self.control(w,'contact-search-input')
  if search.iface_value.CurrentValue!=entry['query']:raise ValueError('Ô tìm kiếm đã thay đổi; tìm lại để tránh chọn nhầm')
  element=entry['element']
  if any(part.window_text().strip()!=name for part,name in entry['parts']) or not element.is_visible():raise ValueError('Kết quả Zalo đã thay đổi; tìm lại')
  element.click_input();time.sleep(.5)
  if not self.header_matches(w,entry['name']):raise ValueError('Chưa xác minh được tên ở đầu cuộc trò chuyện; không soạn/gửi tự động')
  self.selected={'name':entry['name'],'pid':w.process_id(),'window':w.handle};self.draft=None
  return {'ok':True,'recipient':entry['name'],'selected':True,'notice':'Đã xác minh tiêu đề cuộc trò chuyện; chưa gửi tin'}
 def text(self,rich):
  text=None
  try:
   value=rich.iface_value
   if value is not None:text=value.CurrentValue
  except Exception:pass
  if text is None:
   text='\n'.join(c.window_text() for c in rich.descendants(control_type='Text') if c.is_visible())
  if self.selected and normalize(text)==normalize('Nhập @, tin nhắn tới '+self.selected['name']):return ''
  return text
 def focused(self,w,rich):
  from pywinauto.uia_defines import IUIA
  if ctypes.windll.user32.GetForegroundWindow()!=w.handle:return False
  uia=IUIA().iuia;element=uia.GetFocusedElement()
  for _ in range(8):
   if not element:return False
   if element.CurrentProcessId!=w.process_id():return False
   if element.CurrentAutomationId=='richInput':return True
   element=uia.ControlViewWalker.GetParentElement(element)
  return False
 def literal(self,w,rich,text):
  rich.click_input()
  rich.set_focus()
  for _ in range(20):
   if self.focused(w,rich):break
   time.sleep(.05)
  for character in text:
   if not self.focused(w,rich):raise ValueError('Con trỏ đã rời ô soạn Zalo; dừng nhập để tránh gõ nhầm ứng dụng')
   if character=='\r':continue
   if character=='\n':emit([key(0x10),key(0x0D),key(0x0D,True),key(0x10,True)])
   else:
    encoded=character.encode('utf-16-le');events=[]
    for at in range(0,len(encoded),2):unit=int.from_bytes(encoded[at:at+2],'little');events.extend([key(0,scan=unit,unicode=True),key(0,True,scan=unit,unicode=True)])
    emit(events)
 def compose(self,values):
  text=str(values.get('text',''))
  if not text or len(text)>1500 or any(ord(c)<32 and c not in '\n\r\t' for c in text):raise ValueError('Nội dung nháp cần từ 1–1500 ký tự, không chứa phím điều khiển')
  if not self.selected:raise ValueError('Tìm và chọn liên lạc trước')
  w=self.window();recipient=self.selected['name']
  if w.process_id()!=self.selected['pid'] or not self.header_matches(w,recipient):raise ValueError('Cuộc trò chuyện đã đổi; chọn lại liên lạc')
  rich=self.control(w,'richInput');existing=self.text(rich)
  if existing.replace('\r\n','\n').strip()==text.replace('\r\n','\n').strip():
   self.draft={'id':uuid.uuid4().hex,'recipient':recipient,'text':text,'pid':w.process_id(),'created':time.time()}
   return {'ok':True,'draft_id':self.draft['id'],'recipient':recipient,'text':text,'sent':False,'requires_explicit_send':True,'notice':'Bản nháp hiện có khớp nội dung bạn yêu cầu'}
  if existing.strip() and (not self.draft or existing.strip()!=self.draft['text'].strip()):raise ValueError('Ô soạn đang có nội dung khác; chưa ghi đè bản nháp của bạn')
  if existing.strip():raise ValueError('Đang có bản nháp; xóa trên PC hoặc gửi bản nháp hiện có trước')
  self.literal(w,rich,text);time.sleep(.3);actual=self.text(rich)
  if actual.replace('\r\n','\n').strip()!=text.replace('\r\n','\n').strip():raise ValueError('Đã nhập nháp nhưng UIA chưa xác minh đầy đủ nội dung; kiểm tra trên PC, chưa gửi tin')
  self.draft={'id':uuid.uuid4().hex,'recipient':recipient,'text':text,'pid':w.process_id(),'created':time.time()}
  return {'ok':True,'draft_id':self.draft['id'],'recipient':recipient,'text':text,'sent':False,'requires_explicit_send':True}
 def send(self,values):
  draft=self.draft
  if values.get('confirm') is not True or not draft or values.get('draft_id')!=draft['id']:raise ValueError('Cần lệnh gửi riêng với draft_id đúng và confirm=true')
  if time.time()-draft['created']>600:raise ValueError('Bản nháp đã quá 10 phút; kiểm tra lại trước khi gửi')
  w=self.window();rich=self.control(w,'richInput')
  if w.process_id()!=draft['pid'] or not self.header_matches(w,draft['recipient']):raise ValueError('Người nhận đã thay đổi; không gửi')
  if self.text(rich).replace('\r\n','\n').strip()!=draft['text'].replace('\r\n','\n').strip():raise ValueError('Nội dung đã thay đổi; không gửi')
  rich.set_focus()
  for _ in range(20):
   if self.focused(w,rich):break
   time.sleep(.05)
  if not self.focused(w,rich):raise ValueError('Ô soạn chưa được chọn; không gửi')
  emit([key(0x0D),key(0x0D,True)]);time.sleep(.8)
  if self.text(self.control(w,'richInput')).strip():raise ValueError('Chưa xác nhận ô soạn đã gửi; không tự nhấn thêm phím để tránh gửi trùng')
  self.draft=None
  return {'ok':True,'recipient':draft['recipient'],'sent_to_app':True,'delivery_verified':False,'notice':'Đã thao tác gửi trong Zalo; chưa xác minh người nhận đã đọc/nhận'}
