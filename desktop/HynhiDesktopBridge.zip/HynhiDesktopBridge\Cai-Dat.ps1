# Hynhi Desktop Bridge - cai dat 1 lan, tu chay cung Windows, khong can quyen Admin.
$ErrorActionPreference = 'Stop'
$src = Split-Path -Parent $MyInvocation.MyCommand.Path
$dst = Join-Path $env:LOCALAPPDATA 'HynhiDesktop'
function Find-Python {
  foreach ($c in @(@('py','-3'),@('python'))) {
    try { $v = & $c[0] $c[1..9] -c "import sys;print(sys.version_info[0]*100+sys.version_info[1])" 2>$null
      if ($LASTEXITCODE -eq 0 -and [int]$v -ge 310) { return ,$c } } catch {}
  }
  return $null
}
$py = Find-Python
if (-not $py) {
  Write-Host 'Chua co Python, dang cai Python 3.12 qua winget...'
  winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
  $env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
  $py = Find-Python
  if (-not $py) { throw 'Khong cai duoc Python. Hay cai Python 3.12 tu python.org (tich Add to PATH) roi chay lai Cai-Dat.cmd.' }
}
Write-Host 'Dung Python:' ($py -join ' ')
New-Item -ItemType Directory -Force $dst | Out-Null
Get-ChildItem $src -Exclude '.venv','.local','__pycache__','Cai-Dat.*' | Copy-Item -Destination $dst -Recurse -Force
$venv = Join-Path $dst '.venv'
if (-not (Test-Path (Join-Path $venv 'Scripts\pythonw.exe'))) { & $py[0] $py[1..9] -m venv $venv }
$vpy = Join-Path $venv 'Scripts\python.exe'
& $vpy -m pip install --disable-pip-version-check -q --upgrade pip
& $vpy -m pip install --disable-pip-version-check -q -U pywinauto comtypes pywin32 websockets pycaw psutil yt-dlp
if ($LASTEXITCODE -ne 0) { throw 'pip loi - kiem tra Internet roi chay lai.' }
if (-not (Get-Command ffmpeg -ErrorAction SilentlyContinue)) {
  Write-Host 'Cai ffmpeg (de phat YouTube)...'
  try { winget install -e --id Gyan.FFmpeg --accept-package-agreements --accept-source-agreements } catch { Write-Host 'Khong cai duoc ffmpeg tu dong: hay cai tay (winget install Gyan.FFmpeg).' }
}
$pyw = Join-Path $venv 'Scripts\pythonw.exe'
$cmd = '"{0}" "{1}" --browser-profile default --allow-folder "{2}"' -f $pyw,(Join-Path $dst 'start_hidden.pyw'),$env:USERPROFILE
New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' -Name 'HynhiDesktopBridge' -Value $cmd -PropertyType String -Force | Out-Null
Get-CimInstance Win32_Process -Filter "Name='pythonw.exe'" | Where-Object { $_.CommandLine -like '*start_hidden.pyw*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
Start-Process -FilePath $pyw -ArgumentList ('"{0}" --browser-profile default --allow-folder "{1}"' -f (Join-Path $dst 'start_hidden.pyw'),$env:USERPROFILE) -WindowStyle Hidden
$yt = Join-Path $dst 'start_yt_hidden.pyw'
New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' -Name 'HynhiYoutubeBridge' -Value ('"{0}" "{1}"' -f $pyw,$yt) -PropertyType String -Force | Out-Null
Get-CimInstance Win32_Process -Filter "Name='pythonw.exe'" | Where-Object { $_.CommandLine -like '*start_yt_hidden.pyw*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
Start-Process -FilePath $pyw -ArgumentList ('"{0}"' -f $yt) -WindowStyle Hidden
# Mo cong 8768 de robot lay video (can quyen Admin - hien hop thoai UAC mot lan)
try {
  Start-Process powershell -Verb RunAs -Wait -WindowStyle Hidden -ArgumentList '-NoProfile','-Command','netsh advfirewall firewall delete rule name="Hynhi YouTube" | Out-Null; netsh advfirewall firewall add rule name="Hynhi YouTube" dir=in action=allow protocol=TCP localport=8768 profile=private,domain | Out-Null'
} catch { Write-Host 'Bo qua mo firewall (ban da tu choi UAC). Neu robot khong phat duoc YouTube, chay lai Cai-Dat.cmd va chon Yes.' }
Write-Host ''
Write-Host 'XONG. Bridge dang chay ngam va tu chay moi lan bat may.'
Write-Host 'Robot va may tinh phai cung WiFi. Robot tu ghep noi sau khoang 1 phut (khong can nhap gi).'
Write-Host 'Thu: noi voi robot "Mo YouTube" hoac "Phat bai Lac Troi tren YouTube" - video chieu tren man hinh robot.'
