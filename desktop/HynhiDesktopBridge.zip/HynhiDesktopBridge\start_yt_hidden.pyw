"""Hidden logon entry for the Hynhi YouTube bridge (port 8768)."""
import os,runpy,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent
state=root/'.local';state.mkdir(exist_ok=True)
sys.stdout=sys.stderr=(state/'youtube.log').open('a',encoding='utf-8',buffering=1)
sys.stdin=open(os.devnull,encoding='utf-8')
extra=[str(root/'.venv'/'Scripts')]
for base in (os.environ.get('LOCALAPPDATA',''),os.environ.get('ProgramFiles',''),os.environ.get('ProgramData','')):
    for sub in ('Microsoft/WinGet/Links','ffmpeg/bin','chocolatey/bin'):
        p=Path(base)/sub
        if p.is_dir():extra.append(str(p))
os.environ['PATH']=os.pathsep.join(extra+[os.environ.get('PATH','')])
sys.path.insert(0,str(root))
sys.argv=['youtube_bridge.py']
runpy.run_path(str(root/'youtube_bridge.py'),run_name='__main__')
